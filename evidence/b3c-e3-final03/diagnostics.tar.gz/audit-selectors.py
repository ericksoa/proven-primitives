from pathlib import Path
import re,json
R=Path.cwd();s=(R/'tests/proof_rejection.rs').read_text();q=r'("(?:[^"\\]|\\.)*")'
def tuples(text,n):return [tuple(json.loads(v) for v in row) for row in re.findall(r'\(\s*'+r'\s*,\s*'.join([q]*n)+r'\s*,?\s*\)',text)]
def block(fn,loop):
 a=s.index('fn '+fn+'()');a=s.index(loop,a);b=s.index('    ] {',a);return s[a:b]
def body(file,function):
 text=(R/'src'/file).read_text()
 if function.startswith('BrotliDecoder::'):
  name=function.split('::')[-1];begin='    fn '+name+'(';following={'emit_byte':'    fn emit_uncompressed_byte(','emit_uncompressed_byte':'    fn fail_transition('}[name];marker='\n    {\n'
 elif function.startswith('write_b3c_state_'):
  begin='pub(crate) fn '+function+'(';following={'write_b3c_state_byte':'pub(crate) open spec fn b3c_scalar_u16_at','write_b3c_state_u32':'proof fn decode_b3c_u64_le','write_b3c_state_u64':'pub(crate) fn initialize_serialized_b3c('}[function];marker='\n{\n'
 else:begin='fn output_block_reason(';following='pub struct RequestLimits';marker='\n{\n'
 a=text.index(begin);b=text.index(following,a);part=text[a:b];return part[part.index(marker):]
errors=[];count=0
old=tuples(block('the_prover_rejects_twenty_eight_b3c_layout_state_resource_and_output_defects','    for (name, module, file, function, old, new) in ['),6);assert len(old)==28
for name,module,file,fn,old,new in old:
 n=(R/'src'/file).read_text().count(old);count+=1
 if n!=1:errors.append({'case':name,'matches':n})
rows=tuples(block('the_prover_rejects_ten_b3c_atomic_emission_defects','    for (name, function, old, new) in ['),4);assert len(rows)==10
for name,fn,old,new in rows:
 n=body('brotli.rs',fn).count(old);count+=1
 if n!=1:errors.append({'case':name,'matches':n})
rows=tuples(block('the_prover_rejects_twelve_e3_store_receipt_and_billing_defects','    for (name, module, function, old, new) in ['),5);assert len(rows)==12
for name,module,fn,old,new in rows:
 n=body('brotli_input.rs' if module=='input' else 'brotli.rs',fn).count(old);count+=1
 if n!=1:errors.append({'case':name,'matches':n})
result={'cases':count,'selector_errors':errors};(R/'target/b3c-e3/selector-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert not errors
