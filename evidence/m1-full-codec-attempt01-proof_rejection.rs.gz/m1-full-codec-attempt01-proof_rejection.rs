//! Reproducible negative controls: compilation alone must not count as a proof.
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

#[test]
fn project_source_contains_no_proof_trust_bypasses() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        let source = fs::read_to_string(root.join(name)).unwrap();
        for forbidden in [
            "assume(",
            "admit(",
            "assume_specification",
            "external_body",
            "verifier::external",
            "uninterp spec",
            "axiom fn",
            "inline_air_stmt",
            "exec_allows_no_decreases_clause",
        ] {
            assert!(
                !source.contains(forbidden),
                "{name} contains forbidden proof shortcut {forbidden}"
            );
        }
    }
}

fn check(verus: &Path, root: &Path) -> std::process::Output {
    Command::new(verus)
        .arg(root.join("src/lib.rs"))
        .args([
            "--crate-type",
            "lib",
            "--no-cheating",
            "--num-threads",
            "1",
            "--triggers-mode",
            "silent",
            "--rlimit",
            "60",
        ])
        .current_dir(root)
        .output()
        .expect("run pinned Verus")
}

fn check_brotli_prefix_function(verus: &Path, root: &Path, function: &str) -> std::process::Output {
    Command::new(verus)
        .arg(root.join("src/lib.rs"))
        .args([
            "--crate-type",
            "lib",
            "--verify-only-module",
            "brotli_prefix",
            "--verify-function",
            function,
            "--no-cheating",
            "--num-threads",
            "1",
            "--triggers-mode",
            "silent",
            "--rlimit",
            "60",
        ])
        .current_dir(root)
        .output()
        .expect("run selected pinned Verus root")
}

fn check_brotli_input_function(verus: &Path, root: &Path, function: &str) -> std::process::Output {
    Command::new(verus)
        .arg(root.join("src/lib.rs"))
        .args([
            "--crate-type",
            "lib",
            "--verify-only-module",
            "brotli_input",
            "--verify-function",
            function,
            "--no-cheating",
            "--num-threads",
            "1",
            "--triggers-mode",
            "silent",
            "--rlimit",
            "1000",
            "--multiple-errors",
            "0",
        ])
        .current_dir(root)
        .output()
        .expect("run selected pinned Verus input root")
}

fn check_brotli_block_function(verus: &Path, root: &Path, function: &str) -> std::process::Output {
    Command::new(verus)
        .arg(root.join("src/lib.rs"))
        .args([
            "--crate-type",
            "lib",
            "--verify-only-module",
            "brotli_block",
            "--verify-function",
            function,
            "--no-cheating",
            "--num-threads",
            "1",
            "--triggers-mode",
            "silent",
            "--rlimit",
            "60",
        ])
        .current_dir(root)
        .output()
        .expect("run selected pinned Verus block root")
}

fn check_brotli_function(verus: &Path, root: &Path, function: &str) -> std::process::Output {
    Command::new(verus)
        .arg(root.join("src/lib.rs"))
        .args([
            "--crate-type",
            "lib",
            "--verify-only-module",
            "brotli",
            "--verify-function",
            function,
            "--no-cheating",
            "--num-threads",
            "1",
            "--triggers-mode",
            "silent",
            "--rlimit",
            "60",
        ])
        .current_dir(root)
        .output()
        .expect("run selected pinned Verus public Brotli root")
}

fn check_brotli_data_function(verus: &Path, root: &Path, function: &str) -> std::process::Output {
    Command::new(verus)
        .arg(root.join("src/lib.rs"))
        .args([
            "--crate-type",
            "lib",
            "--verify-only-module",
            "brotli_data",
            "--verify-function",
            function,
            "--no-cheating",
            "--num-threads",
            "1",
            "--triggers-mode",
            "silent",
            "--rlimit",
            "60",
        ])
        .current_dir(root)
        .output()
        .expect("run selected pinned Verus Brotli data root")
}

fn check_brotli_data_function_high(
    verus: &Path,
    root: &Path,
    function: &str,
) -> std::process::Output {
    Command::new(verus)
        .arg(root.join("src/lib.rs"))
        .args([
            "--crate-type",
            "lib",
            "--verify-only-module",
            "brotli_data",
            "--verify-function",
            function,
            "--no-cheating",
            "--num-threads",
            "1",
            "--triggers-mode",
            "silent",
            "--rlimit",
            "300",
        ])
        .current_dir(root)
        .output()
        .expect("run selected high-limit Brotli data root")
}

fn transcript(output: &std::process::Output) -> String {
    format!(
        "{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_twenty_eight_semantic_and_security_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let version = Command::new(&verus)
        .arg("--version")
        .output()
        .expect("read Verus version");
    assert!(version.status.success());
    assert!(String::from_utf8_lossy(&version.stdout).contains("0.2026.10.18.7d82994"));
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary =
        std::env::temp_dir().join(format!("proven-primitives-canaries-{}", std::process::id()));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    let sources = [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ];
    for name in sources {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    fs::create_dir_all(project.join("evidence")).unwrap();
    let baseline = check(&verus, &temporary);
    fs::write(
        project.join("evidence/canary-baseline.log"),
        transcript(&baseline),
    )
    .unwrap();
    assert!(
        baseline.status.success(),
        "unmodified positive control failed: {}",
        transcript(&baseline)
    );
    for (name, file, old, new) in [
        (
            "composition-passes-stale-scratch-suffix",
            "composition_demo.rs",
            "let middle = &scratch[..middle_n];",
            "let middle = &scratch[..];",
        ),
        (
            "composition-retains-length-on-base64-error",
            "composition_demo.rs",
            "self.published_len = None;\n        let ghost mut adapter_transitions: nat = 1;",
            "let ghost mut adapter_transitions: nat = 1;",
        ),
        (
            "composition-retains-length-on-percent-error",
            "composition_demo.rs",
            "Err(Error::InvalidInput) => {\n                proof { assert(adapter_transitions <= 8); }\n                return Err(ComposeError::PercentInvalid);\n            }",
            "Err(Error::InvalidInput) => {\n                proof { assert(adapter_transitions <= 8); }\n                self.published_len = Some(1);\n                return Err(ComposeError::PercentInvalid);\n            }",
        ),
        (
            "composition-publishes-whole-output",
            "composition_demo.rs",
            "self.published_len = Some(n);",
            "self.published_len = Some(output.len());",
        ),
        (
            "composition-collapses-base64-error",
            "composition_demo.rs",
            "return Err(ComposeError::Base64Invalid);",
            "return Err(ComposeError::ScratchTooSmall);",
        ),
        (
            "composition-omits-percent-work",
            "percent.rs",
            "let ghost mut decode_work: nat = 8 * input.len() as nat + 16;",
            "let ghost mut decode_work: nat = 16;",
        ),
        (
            "composition-rolls-back-scratch-after-downstream-error",
            "composition_demo.rs",
            "proof { assert(adapter_transitions <= 8); }\n                return Err(ComposeError::PercentInvalid);",
            "proof { assert(adapter_transitions <= 8); }\n                if scratch.len() > 0 { scratch[0] = 0; }\n                return Err(ComposeError::PercentInvalid);",
        ),
        (
            "brotli-block-switch-error-becomes-retryable",
            "brotli_block.rs",
            "return SwitchStep { consumed_fields: 0,\n                status: SwitchStatus::Failed(BlockSwitchError::InvalidBlockSwitch) };",
            "return SwitchStep { consumed_fields: 0,\n                status: SwitchStatus::NeedInput };",
        ),
        (
            "brotli-canonical-code-wrong-recurrence",
            "brotli_prefix.rs",
            "code = combined * 2;",
            "code = combined * 2 + 1;",
        ),
        (
            "brotli-workspace-record-offset-shifted",
            "brotli_prefix.rs",
            "let bytes = record * TREE_RECORD_BYTES;\n    let relative = region_offset + bytes;\n    let absolute = window_bytes + relative;",
            "let bytes = record * TREE_RECORD_BYTES;\n    let relative = region_offset + bytes;\n    let absolute = window_bytes + relative + 1;",
        ),
        (
            "brotli-workspace-reads-uninitialized-record",
            "brotli_prefix.rs",
            "if symbol >= initialized {",
            "if symbol > initialized {",
        ),
        (
            "brotli-workspace-total-off-by-one",
            "brotli_prefix.rs",
            "pub(crate) const STATE_BYTES: u32 = 16_384;",
            "pub(crate) const STATE_BYTES: u32 = 16_383;",
        ),
        (
            "brotli-pending-off-by-one-append",
            "brotli_input.rs",
            "self.pending[self.len] = byte;",
            "self.pending[self.len + 1] = byte;",
        ),
        (
            "brotli-reader-loses-retained-bit",
            "brotli_input.rs",
            "self.compact_after(width);",
            "self.compact_after(width + 1);",
        ),
        (
            "brotli-window-size-wrong-gap",
            "brotli_input.rs",
            "let window_size = (1u32 << window_bits) - 16;",
            "let window_size = (1u32 << window_bits) - 15;",
        ),
        (
            "brotli-invalid-header-becomes-retryable",
            "brotli_input.rs",
            "let status = HeaderStatus::Failed(HeaderError::InvalidHeader);",
            "let status = HeaderStatus::NeedInput;",
        ),
        (
            "brotli-appends-after-terminal-failure",
            "brotli_input.rs",
            "HeaderPhase::Failed(error) => {\n                return HeaderStep { consumed: 0, status: HeaderStatus::Failed(error) };\n            }",
            "HeaderPhase::Failed(error) => {\n                let _ = self.queue.read_bits(1, input, end_of_input);\n                return HeaderStep { consumed: 0, status: HeaderStatus::Failed(error) };\n            }",
        ),
        (
            "base64-validation-accepts-sentinel",
            "base64.rs",
            "    combined < 64\n}",
            "    (combined & 63) < 64\n}",
        ),
        (
            "base64-validation-small-before-invalid",
            "base64.rs",
            "if 6 > capacity - count { small = true; }",
            "if 6 > capacity - count { return Err(Error::OutputTooSmall); }",
        ),
        (
            "base64-batch-decode-wrong-shift",
            "base64.rs",
            "let x0 = ((packed >> 40) & 255) as u8;",
            "let x0 = ((packed >> 39) & 255) as u8;",
        ),
        (
            "base64-batch-encode-wrong-shift",
            "base64.rs",
            "let v0 = ((packed >> 42) & 63) as u8;",
            "let v0 = ((packed >> 41) & 63) as u8;",
        ),
        (
            "base64-decoder-accepts-null",
            "base64.rs",
            "const DECODE_TABLE: [u8; 256] = [\n    255,",
            "const DECODE_TABLE: [u8; 256] = [\n    0,",
        ),
        (
            "wrong-base64-alphabet",
            "base64.rs",
            "65, 66, 67, 68",
            "66, 66, 67, 68",
        ),
        (
            "plus-treated-as-space",
            "percent.rs",
            "if b != b'%' { return Some((b, i + 1)); }",
            "if b != b'%' { return Some((if b == b'+' { b' ' } else { b }, i + 1)); }",
        ),
        (
            "wrong-lz4-backreference",
            "lz4.rs",
            "let byte = output[j - step.offset];",
            "let byte = output[j - 1];",
        ),
        (
            "lz4-reads-stale-destination",
            "lz4.rs",
            "let byte = output[j - step.offset];",
            "let byte = output[j];",
        ),
        (
            "base64-undersized-output-guard",
            "base64.rs",
            "if groups > capacity / 4 {",
            "if groups > capacity / 4 + 1 {",
        ),
        (
            "lz4-fast-fill-reads-stale-destination",
            "lz4.rs",
            "let repeated = output[j - 1];",
            "let repeated = output[j];",
        ),
    ] {
        let path = temporary.join("src").join(file);
        let original = fs::read_to_string(project.join("src").join(file)).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check(&verus, &temporary);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_four_b3a_meta_header_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3a-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    let baseline = check(&verus, &temporary);
    fs::write(
        project.join("evidence/canary-b3a-baseline.log"),
        transcript(&baseline),
    )
    .unwrap();
    assert!(
        baseline.status.success(),
        "unmodified B3a positive control failed: {}",
        transcript(&baseline)
    );
    for (name, old, new) in [
        (
            "brotli-meta-reserved-bit-accepted",
            "MetaBlockPhase::Reserved { is_last } => {\n                if bits != 0 {",
            "MetaBlockPhase::Reserved { is_last } => {\n                if bits == 2 {",
        ),
        (
            "brotli-meta-exuberant-length-accepted",
            "if index + 1 == nibbles && nibbles > 4 && bits == 0 {",
            "if index + 1 == nibbles && nibbles > 4 && bits == 16 {",
        ),
        (
            "brotli-meta-exuberant-metadata-length-accepted",
            "if index + 1 == bytes && bytes > 1 && bits == 0 {",
            "if index + 1 == bytes && bytes > 1 && bits == 256 {",
        ),
        (
            "brotli-meta-truncation-becomes-retryable",
            "status: MetaBlockStatus::Failed(MetaBlockError::Truncated),",
            "status: MetaBlockStatus::NeedInput,",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check(&verus, &temporary);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_two_b3a_record_frame_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3a-frame-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in ["write_next_tree_record", "read_tree_record"] {
        let positive = check_brotli_prefix_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-workspace-write-swaps-code-bytes",
            "write_next_tree_record",
            "workspace[at + 1] = (record.code % 256) as u8;",
            "workspace[at + 1] = (record.code / 256) as u8;",
        ),
        (
            "brotli-workspace-read-uses-length-as-code-byte",
            "read_tree_record",
            "code: workspace[at + 1] as u16 | ((workspace[at + 2] as u16) << 8),",
            "code: workspace[at] as u16 | ((workspace[at + 2] as u16) << 8),",
        ),
    ] {
        let path = temporary.join("src/brotli_prefix.rs");
        let original = fs::read_to_string(project.join("src/brotli_prefix.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_prefix_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_b3a_builder_storage_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3a-builder-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "write_next_builder_code_length",
        "read_builder_code_length",
        "write_next_builder_count",
        "write_next_builder_next_code",
        "write_next_tree_record",
        "install_builder_canonical_tree",
    ] {
        let positive = check_brotli_prefix_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-builder-code-length-write-shifts-region",
            "write_next_builder_code_length",
            "BUILDER_CODE_LENGTHS_OFFSET,\n        BUILDER_CODE_LENGTHS,\n        1,\n        initialized,",
            "BUILDER_CODE_LENGTHS_OFFSET + 1,\n        BUILDER_CODE_LENGTHS,\n        1,\n        initialized,",
        ),
        (
            "brotli-builder-code-length-reads-uninitialized-entry",
            "read_builder_code_length",
            "if index >= initialized {\n        return Err(WorkspaceError::UninitializedRecord);\n    }\n    proof { fixed_layout_is_exact(); }\n    let at = match builder_entry_offset(\n        window_bytes,\n        BUILDER_CODE_LENGTHS_OFFSET,",
            "if index > initialized {\n        return Err(WorkspaceError::UninitializedRecord);\n    }\n    proof { fixed_layout_is_exact(); }\n    let at = match builder_entry_offset(\n        window_bytes,\n        BUILDER_CODE_LENGTHS_OFFSET,",
        ),
        (
            "brotli-builder-count-write-swaps-low-byte",
            "write_next_builder_count",
            "workspace[at] = (value % 256) as u8;\n    workspace[at + 1] = (value / 256) as u8;\n    Ok(initialized + 1)\n}\n\npub(crate) fn read_builder_count",
            "workspace[at] = (value / 256) as u8;\n    workspace[at + 1] = (value / 256) as u8;\n    Ok(initialized + 1)\n}\n\npub(crate) fn read_builder_count",
        ),
        (
            "brotli-builder-next-code-writes-wrong-third-byte",
            "write_next_builder_next_code",
            "workspace[at + 2] = ((value / 65_536) % 256) as u8;\n    workspace[at + 3] = (value / 16_777_216) as u8;\n    Ok(initialized + 1)\n}\n\npub(crate) fn read_builder_next_code",
            "workspace[at + 2] = ((value / 32_768) % 256) as u8;\n    workspace[at + 3] = (value / 16_777_216) as u8;\n    Ok(initialized + 1)\n}\n\npub(crate) fn read_builder_next_code",
        ),
        (
            "brotli-canonical-record-rejects-unused-zero-length",
            "write_next_tree_record",
            "if record.length > MAX_BITS {",
            "if record.length == 0 || record.length > MAX_BITS {",
        ),
        (
            "brotli-canonical-installation-assigns-next-code",
            "install_builder_canonical_tree",
            "record.code = combined as u16;",
            "record.code = (combined + 1) as u16;",
        ),
    ] {
        let path = temporary.join("src/brotli_prefix.rs");
        let original = fs::read_to_string(project.join("src/brotli_prefix.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_prefix_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_four_b3b_inverse_mtf_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-mtf-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in ["inverse_mtf_context_map", "mtf_move_rank"] {
        let positive = check_brotli_prefix_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-mtf-initializes-list-to-zero",
            "inverse_mtf_context_map",
            "workspace[list_base + init as usize] = init as u8;",
            "workspace[list_base + init as usize] = 0;",
        ),
        (
            "brotli-mtf-shifts-from-current-cell",
            "mtf_move_rank",
            "let source_index = (cursor - 1) as usize;",
            "let source_index = cursor as usize;",
        ),
        (
            "brotli-mtf-undercharges-each-rank",
            "inverse_mtf_context_map",
            "work = work + 2 * rank as u64 + 6;",
            "work = work + 2 * rank as u64 + 5;",
        ),
        (
            "brotli-mtf-reuses-too-little-list-prefix",
            "inverse_mtf_context_map",
            "let next_bound = rank_or >> 2;",
            "let next_bound = rank_or >> 3;",
        ),
    ] {
        let path = temporary.join("src/brotli_prefix.rs");
        let original = fs::read_to_string(project.join("src/brotli_prefix.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_prefix_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_b3b_metadata_map_and_coverage_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-map-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "write_tree_metadata",
        "fixed_layout_is_exact",
        "read_tree_metadata",
        "context_entry_offset",
        "read_context_entry",
        "check_context_tree_coverage",
    ] {
        let positive = check_brotli_prefix_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-metadata-single-uses-wrong-tag-bit",
            "write_tree_metadata",
            "proof { single_metadata_descriptor_is_exact(symbol); }\n            0x8000u16 | symbol",
            "proof { single_metadata_descriptor_is_exact(symbol); }\n            0x4000u16 | symbol",
        ),
        (
            "brotli-metadata-block-length-overlaps-block-type",
            "fixed_layout_is_exact",
            "pub(crate) const BLOCK_LENGTH_METADATA_OFFSET: u32 = 1_163_260;",
            "pub(crate) const BLOCK_LENGTH_METADATA_OFFSET: u32 = 1_163_248;",
        ),
        (
            "brotli-metadata-reads-first-inactive-record",
            "read_tree_metadata",
            "if tree >= initialized_prefix {",
            "if tree > initialized_prefix {",
        ),
        (
            "brotli-distance-context-map-uses-literal-region",
            "context_entry_offset",
            "ContextMapKind::Distance => (DISTANCE_CONTEXT_MAP_OFFSET, DISTANCE_CONTEXT_MAP_BYTES),",
            "ContextMapKind::Distance => (LITERAL_CONTEXT_MAP_OFFSET, DISTANCE_CONTEXT_MAP_BYTES),",
        ),
        (
            "brotli-context-map-reads-first-uninitialized-entry",
            "read_context_entry",
            "if num_htrees == 0 || num_htrees > 256 {\n        return Err(WorkspaceError::InvalidSymbol);\n    }\n    if index >= initialized {",
            "if num_htrees == 0 || num_htrees > 256 {\n        return Err(WorkspaceError::InvalidSymbol);\n    }\n    if index > initialized {",
        ),
        (
            "brotli-context-coverage-accepts-any-present-tree",
            "check_context_tree_coverage",
            "complete = complete && present;",
            "complete = complete || present;",
        ),
    ] {
        let path = temporary.join("src/brotli_prefix.rs");
        let original = fs::read_to_string(project.join("src/brotli_prefix.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_prefix_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_two_b3b_distance_and_exhaustion_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-input-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in ["decode_distance_parameters", "advance_var_uint8"] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-distance-postfix-uses-upper-four-bits",
            "decode_distance_parameters",
            "let postfix = bits % 4;\n    let upper = bits / 4;",
            "let postfix = bits / 4;\n    let upper = bits / 4;",
        ),
        (
            "brotli-varuint-final-exhaustion-needs-more-input",
            "advance_var_uint8",
            "BitReadStatus::Truncated => return VarUint8Step {\n            consumed: read.consumed,\n            status: VarUint8Status::Truncated,",
            "BitReadStatus::Truncated => return VarUint8Step {\n            consumed: read.consumed,\n            status: VarUint8Status::NeedInput,",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_b3b_adapter_failure_as_retryable() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-adapter-canary-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    let function = "advance_b3b_switch";
    let positive = check_brotli_block_function(&verus, &temporary, function);
    assert!(
        positive.status.success(),
        "unmodified selected root failed: {}",
        transcript(&positive)
    );
    let name = "brotli-b3b-adapter-turns-failure-into-need-input";
    let old = "SwitchStatus::Failed(error) => {\n            B3bSwitchOutcome::Failed(b2_failure_to_b3b(error))\n        }";
    let new =
        "SwitchStatus::Failed(_error) => {\n            B3bSwitchOutcome::NeedInput\n        }";
    let path = temporary.join("src/brotli_block.rs");
    let original = fs::read_to_string(project.join("src/brotli_block.rs")).unwrap();
    assert_eq!(
        original.matches(old).count(),
        1,
        "unique mutation anchor for {name}"
    );
    fs::write(&path, original.replacen(old, new, 1)).unwrap();
    let result = check_brotli_block_function(&verus, &temporary, function);
    let log = transcript(&result);
    fs::write(
        project.join("evidence").join(format!("canary-{name}.log")),
        &log,
    )
    .unwrap();
    assert!(!result.status.success(), "prover accepted {name}");
    assert!(
        log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("assertion failed"),
        "expected a proof rejection, not a tooling error: {log}"
    );
    println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
    fs::write(&path, original).unwrap();
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_b3a_code_description_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3a-code-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "*CodeDescriptionDecoder*",
        "process_complex_code_length",
        "code_length_order_is_rfc",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-code-selector-misclassifies-simple",
            "*CodeDescriptionDecoder*",
            "assert(field < 4);\n                if field == 1 {",
            "assert(field < 4);\n                if field == 0 {",
        ),
        (
            "brotli-simple-code-accepts-limit-value",
            "*CodeDescriptionDecoder*",
            "if field >= self.alphabet_limit as u64 {",
            "if field > self.alphabet_limit as u64 {",
        ),
        (
            "brotli-simple-code-accepts-duplicate-symbol",
            "*CodeDescriptionDecoder*",
            "if duplicate {",
            "if duplicate && symbol == u16::MAX {",
        ),
        (
            "brotli-complex-static-prefix-maps-four-to-five",
            "*CodeDescriptionDecoder*",
            "process_complex_code_length(progress, 4)",
            "process_complex_code_length(progress, 5)",
        ),
        (
            "brotli-complex-code-misclassifies-space-overflow",
            "process_complex_code_length",
            "if amount > progress.space {\n            return CodeDescriptionPhase::Failed(CodeDescriptionError::CodeLengthSpace);",
            "if amount > progress.space {\n            return CodeDescriptionPhase::Failed(CodeDescriptionError::InvalidAlphabet);",
        ),
        (
            "brotli-code-length-order-starts-at-zero",
            "code_length_order_is_rfc",
            "const CODE_LENGTH_ORDER: [u8; 18] = [\n    1, 2, 3, 4, 0, 5,",
            "const CODE_LENGTH_ORDER: [u8; 18] = [\n    0, 2, 3, 4, 0, 5,",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_b3a_auxiliary_code_without_bit_reversal() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3a-reversal-canary-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }

    let function = "decode_auxiliary_symbol";
    let positive = check_brotli_input_function(&verus, &temporary, function);
    assert!(
        positive.status.success(),
        "unmodified selected root failed: {}",
        transcript(&positive)
    );

    let name = "brotli-auxiliary-code-compares-natural-instead-of-reversed";
    let old = "let reversed = reverse_auxiliary_code(candidate, width);\n                if reversed == bits {";
    let new = "let reversed = reverse_auxiliary_code(candidate, width);\n                if candidate == bits as u32 {";
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
    let start = original
        .find(&format!("fn {function}("))
        .expect("selected function exists");
    let end = start
        + original[start..]
            .find("\n}\n")
            .expect("selected function ends")
        + 3;
    let selected = &original[start..end];
    assert_eq!(
        selected.matches(old).count(),
        1,
        "unique mutation anchor for {name}"
    );
    fs::write(
        &path,
        format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        ),
    )
    .unwrap();
    let result = check_brotli_input_function(&verus, &temporary, function);
    let log = transcript(&result);
    fs::write(
        project.join("evidence").join(format!("canary-{name}.log")),
        &log,
    )
    .unwrap();
    assert!(!result.status.success(), "prover accepted {name}");
    assert!(
        log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("assertion failed"),
        "expected a proof rejection, not a tooling error: {log}"
    );
    println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
    fs::write(&path, original).unwrap();
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_two_b3b_state_layout_and_bit_order_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-layout-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in ["b3b_scalar_layout_is_exact", "reverse_installed_code"] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-b3b-outer-phase-overlaps-terminal-tag",
            "b3b_scalar_layout_is_exact",
            "const B3B_OUTER_PHASE: u16 = 10;",
            "const B3B_OUTER_PHASE: u16 = 11;",
        ),
        (
            "brotli-installed-code-omits-reversed-head-bit",
            "reverse_installed_code",
            "installed_reverse_combine_fits(bit, width, rest);\n        }\n        bit * (1u16 << ((width - 1) as u8)) + rest",
            "installed_reverse_combine_fits(bit, width, rest);\n        }\n        rest",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_b3b_installed_symbol_without_bit_reversal() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-installed-canary-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    let function = "advance_installed_tree_symbol";
    let positive = check_brotli_input_function(&verus, &temporary, function);
    assert!(
        positive.status.success(),
        "unmodified selected root failed: {}",
        transcript(&positive)
    );
    let name = "brotli-installed-symbol-compares-natural-code";
    let old = "if reversed == next_bits {";
    let new = "if record.code == next_bits {";
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
    assert_eq!(
        original.matches(old).count(),
        1,
        "unique mutation anchor for {name}"
    );
    fs::write(&path, original.replacen(old, new, 1)).unwrap();
    let result = check_brotli_input_function(&verus, &temporary, function);
    let log = transcript(&result);
    fs::write(
        project.join("evidence").join(format!("canary-{name}.log")),
        &log,
    )
    .unwrap();
    assert!(!result.status.success(), "prover accepted {name}");
    assert!(
        log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("assertion failed"),
        "expected a proof rejection, not a tooling error: {log}"
    );
    println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
    fs::write(&path, original).unwrap();
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_four_b3b_block_count_and_category_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-block-count-canary-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "*CompressedMetaBlockDecoder*",
        "CompressedMetaBlockDecoder::apply_block_count_value",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-b3b-one-type-initial-length-is-short",
            "CompressedMetaBlockDecoder::apply_block_count_value",
            "put_state_u32(\n                self.workspace,\n                self.window_bytes,\n                B3B_INITIAL_LENGTHS + 4 * kind as u16,\n                1u32 << 24,\n            )?;",
            "put_state_u32(\n                self.workspace,\n                self.window_bytes,\n                B3B_INITIAL_LENGTHS + 4 * kind as u16,\n                1u32 << 23,\n            )?;",
        ),
        (
            "brotli-b3b-block-count-omits-plus-one",
            "*CompressedMetaBlockDecoder*",
            "let count = raw + 1;",
            "let count = if raw == 0 { 1 } else { raw };",
        ),
        (
            "brotli-b3b-one-type-category-builds-trees",
            "*CompressedMetaBlockDecoder*",
            "if count == 1 {",
            "if count == 1 && kind == 255 {",
        ),
        (
            "brotli-b3b-category-order-skips-command",
            "*CompressedMetaBlockDecoder*",
            "B3B_CURRENT_KIND,\n                kind + 1,",
            "B3B_CURRENT_KIND,\n                if kind == 0 { 2 } else { kind + 1 },",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_thirteen_b3b_context_map_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-context-tree-count-canary-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "advance_context_tree_count_phase",
        "advance_context_bits_phase",
        "advance_context_symbol_phase",
        "advance_context_coverage_phase",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-b3b-context-tree-count-omits-plus-one-for-zero",
            "advance_context_tree_count_phase",
            "let num_trees = raw + 1;",
            "let num_trees = if raw == 0 { 2 } else { raw + 1 };",
        ),
        (
            "brotli-b3b-context-phase-one-reads-two-bits",
            "advance_context_bits_phase",
            "if phase == 1 {\n                    (1usize, 0u8)",
            "if phase == 1 {\n                    (2usize, 0u8)",
        ),
        (
            "brotli-b3b-context-phase-two-reads-three-bits",
            "advance_context_bits_phase",
            "else if phase == 2 { (4usize, 0u8) }",
            "else if phase == 2 { (3usize, 0u8) }",
        ),
        (
            "brotli-b3b-context-rle-suffix-is-one-bit-short",
            "advance_context_bits_phase",
            "(pending as usize, pending)",
            "((pending - 1) as usize, pending)",
        ),
        (
            "brotli-b3b-context-phase-six-reads-two-bits",
            "advance_context_bits_phase",
            "else if phase == 6 { (1usize, 0u8) }",
            "else if phase == 6 { (2usize, 0u8) }",
        ),
        (
            "brotli-b3b-context-need-input-does-not-suspend",
            "advance_context_bits_phase",
            "BitReadStatus::NeedInput => {\n                        let result = (consumed, Some(ContextAdvanceStatus::NeedInput));",
            "BitReadStatus::NeedInput => {\n                        let result = (consumed, None);",
        ),
        (
            "brotli-b3b-context-exact-fill-is-overflow",
            "advance_context_bits_phase",
            "if index as u32 + repeat > active_len as u32 {",
            "if index as u32 + repeat >= active_len as u32 {",
        ),
        (
            "brotli-b3b-context-rle-writes-one",
            "advance_context_bits_phase",
            "initialized = match crate::brotli_prefix::write_next_context_entry(\n                                    workspace, window_bytes, kind, active_len,\n                                    initialized, 0, num_trees) {",
            "initialized = match crate::brotli_prefix::write_next_context_entry(\n                                    workspace, window_bytes, kind, active_len,\n                                    initialized, 1, num_trees) {",
        ),
        (
            "brotli-b3b-context-temporary-alphabet-adds-one",
            "advance_context_bits_phase",
            "let alphabet = num_trees + max_run as u16;",
            "let alphabet = num_trees + max_run as u16 + 1;",
        ),
        (
            "brotli-b3b-context-zero-mtf-flag-routes-to-mtf",
            "advance_context_bits_phase",
            "} else if value == 0 {\n                            if let Err(error) = store_context_phase(\n                                workspace, window_bytes, 8) {",
            "} else if value == 0 {\n                            if let Err(error) = store_context_phase(\n                                workspace, window_bytes, 7) {",
        ),
        (
            "brotli-b3b-context-direct-value-is-one-low",
            "store_context_direct_symbol",
            "let value = symbol - max_run as u16;\n    proof { bounded_u16_fits_u8(value); }",
            "let value = symbol - max_run as u16 - 1;\n    proof { bounded_u16_fits_u8(value); }",
        ),
        (
            "brotli-b3b-context-symbol-uses-literal-tree-region",
            "advance_context_symbol_phase",
            "let symbol_step = advance_installed_tree_symbol(\n                        workspace,\n                        window_bytes,\n                        crate::brotli_prefix::TreeRegion::TemporaryContext,",
            "let symbol_step = advance_installed_tree_symbol(\n                        workspace,\n                        window_bytes,\n                        crate::brotli_prefix::TreeRegion::Literal,",
        ),
        (
            "brotli-b3b-context-coverage-rejects-covered-map",
            "advance_context_coverage_phase",
            "if !covered {",
            "if covered {",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_b3b_tree_group_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-tree-group-canary-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "CompressedMetaBlockDecoder::advance_tree_groups_phase",
        "CompressedMetaBlockDecoder::group_parameters",
        "CompressedMetaBlockDecoder::complete_tree_groups",
        "install_completed_simple_tree",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-b3b-completed-simple-tree-writes-unused-metadata",
            "install_completed_simple_tree",
            "    match crate::brotli_prefix::write_tree_metadata(\n        workspace,\n        window_bytes,\n        region,\n        tree,\n        meta,\n    ) {",
            "    match crate::brotli_prefix::write_tree_metadata(\n        workspace,\n        window_bytes,\n        region,\n        tree,\n        crate::brotli_prefix::TreeMetadata::unused(),\n    ) {",
        ),
        (
            "brotli-b3b-tree-group-order-skips-command",
            "CompressedMetaBlockDecoder::advance_tree_groups_phase",
            "if group < 2 {\n                                    let next_group = group + 1;\n                                    proof {\n                                        assert(next_group == group + 1);",
            "if group < 2 {\n                                    let next_group = if group == 0 { 2 } else { group + 1 };\n                                    proof {\n                                        assert(next_group == group + 1);",
        ),
        (
            "brotli-b3b-command-group-uses-distance-count",
            "CompressedMetaBlockDecoder::group_parameters",
            "let count = state_u16(\n                    self.workspace, self.window_bytes, B3B_BLOCK_COUNTS + 2)?;",
            "let count = state_u16(\n                    self.workspace, self.window_bytes, B3B_BLOCK_COUNTS + 4)?;",
        ),
        (
            "brotli-b3b-tree-group-index-advances-by-two",
            "CompressedMetaBlockDecoder::advance_tree_groups_phase",
            "let next = tree + 1;",
            "let next = tree + 2;",
        ),
        (
            "brotli-b3b-command-group-alphabet-is-703",
            "CompressedMetaBlockDecoder::group_parameters",
            "Ok((crate::brotli_prefix::TreeRegion::Command, count, 704))",
            "Ok((crate::brotli_prefix::TreeRegion::Command, count, 703))",
        ),
        (
            "brotli-b3b-active-command-tree-starts-at-one",
            "CompressedMetaBlockDecoder::complete_tree_groups",
            "put_state_u16(self.workspace, self.window_bytes, B3B_ACTIVE_COMMAND_TREE, 0)?;",
            "put_state_u16(self.workspace, self.window_bytes, B3B_ACTIVE_COMMAND_TREE, 1)?;",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_b3b_cross_call_state_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-cross-call-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "drain_serialized_pending_span",
        "CompressedMetaBlockDecoder::repeat_terminal_failure",
        "CompressedMetaBlockDecoder::step",
        "store_context_map_progress",
        "advance_context_mtf_phase",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-b3b-pending-span-is-not-drained",
            "drain_serialized_pending_span",
            "let acknowledged = acknowledge_serialized_pending_span(decoder);",
            "let acknowledged = CodeDescriptionStep { consumed: 0, status: CodeDescriptionStatus::Progress };",
        ),
        (
            "brotli-b3b-sticky-failure-consumes-one-byte",
            "CompressedMetaBlockDecoder::repeat_terminal_failure",
            "CompressedHeaderStep {\n            consumed: 0,\n            status: CompressedHeaderStatus::Failed(error),\n        }",
            "CompressedHeaderStep {\n            consumed: 1,\n            status: CompressedHeaderStatus::Failed(error),\n        }",
        ),
        (
            "brotli-b3b-sticky-failure-becomes-need-input",
            "CompressedMetaBlockDecoder::repeat_terminal_failure",
            "CompressedHeaderStep {\n            consumed: 0,\n            status: CompressedHeaderStatus::Failed(error),\n        }",
            "CompressedHeaderStep {\n            consumed: 0,\n            status: CompressedHeaderStatus::NeedInput,\n        }",
        ),
        (
            "brotli-b3b-step-bypasses-sticky-failure-helper",
            "CompressedMetaBlockDecoder::step",
            "return self.repeat_terminal_failure(error);",
            "return CompressedHeaderStep { consumed: input.len(), status: CompressedHeaderStatus::Failed(error) };",
        ),
        (
            "brotli-b3b-context-progress-leaves-stale-initialized-length",
            "store_context_map_progress",
            "put_state_u16(workspace, window_bytes, B3B_MAP_INITIALIZED, progress)",
            "put_state_u16(workspace, window_bytes, B3B_MAP_INDEX, progress)",
        ),
        (
            "brotli-b3b-context-mtf-leaves-stale-reuse-bound",
            "advance_context_mtf_phase",
            "put_state_byte(\n        workspace,\n        window_bytes,\n        B3B_MTF_UPPER_BOUND,\n        next_upper,\n    )",
            "put_state_byte(\n        workspace,\n        window_bytes,\n        B3B_MTF_UPPER_BOUND,\n        upper,\n    )",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_seven_b3b_stride_initialization_and_exhaustion_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-stride-init-exhaustion-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "CompressedMetaBlockDecoder::advance_context_modes_phase",
        "CompressedMetaBlockDecoder::advance_context_maps_phase",
        "start_serialized_tree",
        "advance_context_bits_phase",
        "handle_context_installed_symbol_status",
        "CodeDescriptionDecoder::advance_field",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-b3b-literal-context-row-stride-is-63",
            "CompressedMetaBlockDecoder::advance_context_modes_phase",
            "let active_len = literal_count * 64;",
            "let active_len = literal_count * 63;",
        ),
        (
            "brotli-b3b-distance-context-row-stride-is-three",
            "CompressedMetaBlockDecoder::advance_context_maps_phase",
            "if let Err(error) = start_context_map(\n                                    self.workspace,\n                                    self.window_bytes,\n                                    crate::brotli_prefix::ContextMapKind::Distance,\n                                    distance_types * 4,\n                                )",
            "if let Err(error) = start_context_map(\n                                    self.workspace,\n                                    self.window_bytes,\n                                    crate::brotli_prefix::ContextMapKind::Distance,\n                                    distance_types * 3,\n                                )",
        ),
        (
            "brotli-b3b-serialized-tree-skips-builder-reset",
            "start_serialized_tree",
            "put_state_u16(workspace, window_bytes, B3B_BUILDER_INITIALIZED, 0)",
            "Ok(())",
        ),
        (
            "brotli-b3b-context-tree-starts-in-literal-region",
            "advance_context_bits_phase",
            "if value == 0 {\n                                if let Err(error) = start_serialized_tree(\n                                    workspace,\n                                    window_bytes,\n                                    crate::brotli_prefix::TreeRegion::TemporaryContext,",
            "if value == 0 {\n                                if let Err(error) = start_serialized_tree(\n                                    workspace,\n                                    window_bytes,\n                                    crate::brotli_prefix::TreeRegion::Literal,",
        ),
        (
            "brotli-b3b-installed-symbol-truncation-needs-input",
            "handle_context_installed_symbol_status",
            "InstalledSymbolStatus::Truncated => Some(ContextAdvanceStatus::Failed(\n            CompressedHeaderError::Truncated,\n        )),",
            "InstalledSymbolStatus::Truncated => Some(ContextAdvanceStatus::NeedInput),",
        ),
        (
            "brotli-b3b-context-bit-truncation-needs-input",
            "advance_context_bits_phase",
            "BitReadStatus::Truncated => return (consumed, Some(ContextAdvanceStatus::Failed(CompressedHeaderError::Truncated),)),",
            "BitReadStatus::Truncated => return (consumed, Some(ContextAdvanceStatus::NeedInput)),",
        ),
        (
            "brotli-b3b-tree-field-truncation-needs-input",
            "CodeDescriptionDecoder::advance_field",
            "self.phase = CodeDescriptionPhase::Failed(CodeDescriptionError::Truncated);\n                return CodeDescriptionStep {\n                    consumed: read.consumed,\n                    status: CodeDescriptionStatus::Failed(CodeDescriptionError::Truncated),",
            "self.phase = CodeDescriptionPhase::Failed(CodeDescriptionError::Truncated);\n                return CodeDescriptionStep {\n                    consumed: read.consumed,\n                    status: CodeDescriptionStatus::NeedInput,",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_b3b_serialization_and_error_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3b-state-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "context_zero_repeat_exec",
        "b3b_state_address",
        "write_b3b_state_u16",
        "write_b3b_state_tag",
        "store_terminal_error",
        "load_terminal_error",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-context-repeat-uses-half-base",
            "context_zero_repeat_exec",
            "let base = 1u32 << symbol;",
            "let base = 1u32 << (symbol - 1);",
        ),
        (
            "brotli-b3b-state-address-shifts-scalar-block",
            "b3b_state_address",
            ".checked_add(B3B_SCALAR_OFFSET as usize) {",
            ".checked_add(B3B_SCALAR_OFFSET as usize + 1) {",
        ),
        (
            "brotli-b3b-u16-writes-low-byte-twice",
            "write_b3b_state_u16",
            "proof { encode_b3b_u16_le(value); }\n    workspace[at] = value as u8;\n    workspace[at + 1] = (value >> 8) as u8;",
            "proof { encode_b3b_u16_le(value); }\n    workspace[at] = value as u8;\n    workspace[at + 1] = value as u8;",
        ),
        (
            "brotli-b3b-tag-accepts-first-invalid-value",
            "write_b3b_state_tag",
            "if value >= variants {\n        return Err(crate::brotli_prefix::WorkspaceError::InvalidSymbol);\n    }\n    write_b3b_state_byte",
            "if value > variants {\n        return Err(crate::brotli_prefix::WorkspaceError::InvalidSymbol);\n    }\n    write_b3b_state_byte",
        ),
        (
            "brotli-terminal-store-marks-state-complete",
            "store_terminal_error",
            "write_b3b_state_tag(workspace, window_bytes, B3B_OUTER_PHASE, 13, 12)",
            "write_b3b_state_tag(workspace, window_bytes, B3B_OUTER_PHASE, 13, 11)",
        ),
        (
            "brotli-terminal-load-turns-truncation-unsupported",
            "load_terminal_error",
            "2 if detail == 0 => Ok(CompressedHeaderError::Truncated),",
            "2 if detail == 0 => Ok(CompressedHeaderError::UnsupportedMode),",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_b3a_repeat_stream_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3a-repeat-canaries-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    for function in [
        "start_complex_symbol_progress",
        "process_repeated_symbol_length",
    ] {
        let positive = check_brotli_input_function(&verus, &temporary, function);
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive)
        );
    }
    for (name, function, old, new) in [
        (
            "brotli-repeat-initial-previous-length-is-not-eight",
            "start_complex_symbol_progress",
            "prev_code_len: 8,",
            "prev_code_len: 7,",
        ),
        (
            "brotli-repeat-does-not-reset-after-length-change",
            "process_repeated_symbol_length",
            "let old_repeat = if progress.repeat_code_len != length {\n        0",
            "let old_repeat = if progress.repeat_code_len == length {\n        0",
        ),
        (
            "brotli-repeat-chain-subtracts-one-instead-of-two",
            "process_repeated_symbol_length",
            "(old_repeat - 2) << extra_bits",
            "(old_repeat - 1) << extra_bits",
        ),
        (
            "brotli-repeat-chain-adds-four-instead-of-three",
            "process_repeated_symbol_length",
            "let next_repeat = base + suffix as u32 + 3;",
            "let next_repeat = base + suffix as u32 + 4;",
        ),
        (
            "brotli-repeat-rejects-an-exact-alphabet-fill",
            "process_repeated_symbol_length",
            "if delta > alphabet_limit as u32 - progress.symbol as u32 {",
            "if delta >= alphabet_limit as u32 - progress.symbol as u32 {",
        ),
        (
            "brotli-repeat-undercharges-final-code-space",
            "process_repeated_symbol_length",
            "let amount = weight * delta;",
            "let amount = weight * (delta - 1);",
        ),
    ] {
        let path = temporary.join("src/brotli_input.rs");
        let original = fs::read_to_string(project.join("src/brotli_input.rs")).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_twenty_eight_b3c_layout_state_resource_and_output_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-canaries-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    fs::create_dir_all(project.join("evidence")).unwrap();

    for (module, function) in [
        ("input", "b3c_layout_is_exact"),
        ("input", "initialize_serialized_b3c"),
        ("input", "reject_permanent_single_type_switch"),
        ("input", "distance_lut_value"),
        ("input", "validate_zero_padding"),
        ("input", "validate_dictionary_staging_length"),
        ("input", "validate_initialized_dictionary_index"),
        ("input", "body_decrement_block_remaining"),
        ("brotli", "selected_literal_context"),
        ("brotli", "command_copy_length_context"),
        ("brotli", "BrotliDecoder::commit_eof_if_complete"),
        ("brotli", "phase_after_completed_insert"),
        ("brotli", "next_recent_cursor"),
        ("brotli", "copy_setup_phase"),
        ("brotli", "overlap_source_position"),
        ("brotli", "BrotliDecoder::consume_metadata_byte"),
        ("brotli", "BrotliDecoder::emit_uncompressed_byte"),
        ("brotli", "output_block_reason"),
        ("brotli", "BrotliDecoder::reset"),
        ("brotli", "BrotliDecoder::step"),
        ("data", "distance_index_delta"),
        ("data", "distance_value_delta"),
        ("data", "validate_dictionary_transform_shape"),
        ("data", "zero_length_dictionary_transform_plan"),
        ("brotli", "BrotliDecoder::fail"),
        ("brotli", "BrotliDecoder::emit_byte"),
    ] {
        let positive = match module {
            "input" => check_brotli_input_function(&verus, &temporary, function),
            "brotli" => check_brotli_function(&verus, &temporary, function),
            "data" => check_brotli_data_function(&verus, &temporary, function),
            _ => unreachable!(),
        };
        assert!(
            positive.status.success(),
            "unmodified selected root failed: {}",
            transcript(&positive),
        );
    }

    for (name, module, file, function, old, new) in [
        (
            "brotli-b3c-region-boundary-shifts",
            "input",
            "brotli_input.rs",
            "b3c_layout_is_exact",
            "pub(crate) const B3C_DISTANCE_BITS_OFFSET: u32 = 1_163_660;",
            "pub(crate) const B3C_DISTANCE_BITS_OFFSET: u32 = 1_163_661;",
        ),
        (
            "brotli-b3c-initial-recent-distance-is-wrong",
            "input",
            "brotli_input.rs",
            "initialize_serialized_b3c",
            "if i == B3C_RECENT_DISTANCES as usize { 16 }",
            "if i == B3C_RECENT_DISTANCES as usize { 15 }",
        ),
        (
            "brotli-b3c-terminal-escrow-marker-is-wrong",
            "input",
            "brotli_input.rs",
            "initialize_serialized_b3c",
            "else if i == B3C_TERMINAL_ESCROW_MARKER as usize { 4 }",
            "else if i == B3C_TERMINAL_ESCROW_MARKER as usize { 3 }",
        ),
        (
            "brotli-b3c-distance-lut-offset-is-wrong",
            "input",
            "brotli_input.rs",
            "distance_lut_value",
            "let shifted_wide = shifted_grouped + direct as u64 + 1;",
            "let shifted_wide = shifted_grouped + direct as u64 + 2;",
        ),
        (
            "brotli-b3c-nonzero-padding-is-accepted",
            "input",
            "brotli_input.rs",
            "validate_zero_padding",
            "if value == 0 {\n        Ok(())",
            "if value != 0 {\n        Ok(())",
        ),
        (
            "brotli-b3c-dictionary-output-equal-to-meta-limit-is-rejected",
            "input",
            "brotli_input.rs",
            "validate_dictionary_staging_length",
            "    } else if output_length as u32 > meta_remaining {",
            "    } else if output_length as u32 >= meta_remaining {",
        ),
        (
            "brotli-b3c-dictionary-staging-reads-uninitialized-byte",
            "input",
            "brotli_input.rs",
            "validate_initialized_dictionary_index",
            "    if initialized > 37 || index >= initialized {",
            "    if initialized > 37 || index > initialized {",
        ),
        (
            "brotli-b3c-permanent-block-switch-failure-is-retryable",
            "input",
            "brotli_input.rs",
            "reject_permanent_single_type_switch",
            "        consumed: 0,\n        status: match result.outcome {\n            crate::brotli_block::B3bSwitchOutcome::Failed(error) => {\n                BodySwitchStatus::Failed(map_switch_failure(error))",
            "        consumed: 0,\n        status: match result.outcome {\n            crate::brotli_block::B3bSwitchOutcome::Failed(error) => {\n                BodySwitchStatus::NeedInput",
        ),
        (
            "brotli-b3c-command-remaining-does-not-decrement",
            "input",
            "brotli_input.rs",
            "body_decrement_block_remaining",
            "remaining - 1,\n    )\n    .map_err(map_compressed_error)",
            "remaining,\n    )\n    .map_err(map_compressed_error)",
        ),
        (
            "brotli-b3c-literal-context-previous-bytes-are-swapped",
            "brotli",
            "brotli.rs",
            "selected_literal_context",
            "crate::brotli_data::literal_context(mode, previous, second_previous)",
            "crate::brotli_data::literal_context(mode, second_previous, previous)",
        ),
        (
            "brotli-b3c-copy-length-context-is-wrong",
            "brotli",
            "brotli.rs",
            "command_copy_length_context",
            "    } else if copy_offset <= 4 {\n        (copy_offset - 2) as u8\n    } else {\n        3\n    }\n}",
            "    } else if copy_offset <= 4 {\n        (copy_offset - 1) as u8\n    } else {\n        3\n    }\n}",
        ),
        (
            "brotli-b3c-eof-is-committed-before-slice-consumption",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::commit_eof_if_complete",
            "    {\n        if end && consumed == input_len {",
            "    {\n        if end {",
        ),
        (
            "brotli-b3c-copy-runs-after-insert-reaches-meta-length",
            "brotli",
            "brotli.rs",
            "phase_after_completed_insert",
            "{\n    if meta_remaining == 0 { 15 } else { 8 }\n}",
            "{\n    if meta_remaining == 0 { 8 } else { 8 }\n}",
        ),
        (
            "brotli-b3c-recent-distance-ring-does-not-advance",
            "brotli",
            "brotli.rs",
            "next_recent_cursor",
            "    if cursor == 3 { 0 } else { cursor + 1 }",
            "    cursor",
        ),
        (
            "brotli-b3c-beyond-history-distance-is-treated-as-lz77",
            "brotli",
            "brotli.rs",
            "copy_setup_phase",
            "    if distance <= history { 12 } else { 13 }",
            "    12",
        ),
        (
            "brotli-b3c-overlap-copy-uses-wrong-source",
            "brotli",
            "brotli.rs",
            "overlap_source_position",
            "        position - distance",
            "        position - distance + 1",
        ),
        (
            "brotli-b3c-metadata-changes-history",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::consume_metadata_byte",
            "        let result = crate::brotli_input::write_b3c_state_u32(\n            self.workspace,\n            self.window_bytes(),\n            crate::brotli_input::B3C_META_REMAINING,\n            remaining - 1,",
            "        let result = crate::brotli_input::write_b3c_state_u32(\n            self.workspace,\n            self.window_bytes(),\n            crate::brotli_input::B3C_HISTORY_LENGTH,\n            remaining - 1,",
        ),
        (
            "brotli-b3c-uncompressed-byte-does-not-debit-input",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::emit_uncompressed_byte",
            "        self.emit_byte(byte, output, produced, true)",
            "        self.emit_byte(byte, output, produced, false)",
        ),
        (
            "brotli-b3c-need-output-masks-resource-limit",
            "brotli",
            "brotli.rs",
            "output_block_reason",
            "    if output_remaining == 0 || work_remaining < 8 {\n        1\n    } else if !has_output_slot {\n        2",
            "    if !has_output_slot {\n        2\n    } else if output_remaining == 0 || work_remaining < 8 {\n        1",
        ),
        (
            "brotli-b3c-reset-replenishes-work",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::reset",
            "        let window_bytes = 1u32 << self.budget.limits.max_window_bits;",
            "        self.budget.work_remaining = self.budget.limits.max_work;\n        let window_bytes = 1u32 << self.budget.limits.max_window_bits;",
        ),
        (
            "brotli-b3c-terminal-retry-debits-a-call",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::step",
            "        if let Some(step) = self.terminal_step(phase) {\n            proof {",
            "        if let Some(step) = self.terminal_step(phase) {\n            let _ = self.budget.charge_call();\n            proof {",
        ),
        (
            "brotli-b3c-recent-distance-index-is-wrong",
            "data",
            "brotli_data.rs",
            "distance_index_delta",
            "0 => 3, 1 => 2, 2 => 1, 3 => 0,",
            "0 => 2, 1 => 2, 2 => 1, 3 => 0,",
        ),
        (
            "brotli-b3c-recent-distance-signed-delta-is-wrong",
            "data",
            "brotli_data.rs",
            "distance_value_delta",
            "4 | 10 => -1,",
            "4 | 10 => 1,",
        ),
        (
            "brotli-b3c-dictionary-length-guard-is-weakened",
            "data",
            "brotli_data.rs",
            "validate_dictionary_transform_shape",
            "    if length < 4 || length > 24 {",
            "    if length < 3 || length > 24 {",
        ),
        (
            "brotli-b3c-valid-zero-length-transform-is-rejected",
            "data",
            "brotli_data.rs",
            "zero_length_dictionary_transform_plan",
            "    DictionaryTransformPlan {\n        prefix_at: 216,\n        prefix_len: 0,\n        body_start: 0,\n        body_len: 0,",
            "    DictionaryTransformPlan {\n        prefix_at: 216,\n        prefix_len: 0,\n        body_start: 0,\n        body_len: 1,",
        ),
        (
            "brotli-b3c-failure-is-stored-as-finished",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::fail",
            "crate::brotli_input::B3C_STREAM_PHASE,\n            9,",
            "crate::brotli_input::B3C_STREAM_PHASE,\n            8,",
        ),
        (
            "brotli-b3c-byte-emission-undercharges-work",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::emit_byte",
            "assert!(self.budget.charge_work(8));",
            "assert!(self.budget.charge_work(7));",
        ),
        (
            "brotli-b3c-byte-emission-publishes-wrong-value",
            "brotli",
            "brotli.rs",
            "BrotliDecoder::emit_byte",
            "output[produced] = byte;",
            "output[produced] = byte.wrapping_add(1);",
        ),
    ] {
        let source_path = project.join("src").join(file);
        let temporary_path = temporary.join("src").join(file);
        let original = fs::read_to_string(&source_path).unwrap();
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}",
        );
        fs::write(&temporary_path, original.replacen(old, new, 1)).unwrap();
        let result = match module {
            "input" => check_brotli_input_function(&verus, &temporary, function),
            "brotli" => check_brotli_function(&verus, &temporary, function),
            "data" => check_brotli_data_function(&verus, &temporary, function),
            _ => unreachable!(),
        };
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}",
        );
        println!("REJECTED {name}: deliberately wrong implementation, unchanged specification");
        fs::write(&temporary_path, original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_b3c_exact_symbol_work_undercharge() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-symbol-work-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    let function = "advance_installed_tree_symbol";
    let positive = check_brotli_input_function(&verus, &temporary, function);
    assert!(
        positive.status.success(),
        "unmodified selected root failed: {}",
        transcript(&positive),
    );

    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    let old = "        proof { exact_work = (exact_work + 1) as u64; }\n        let read = queue.read_bits";
    let new = "        proof { exact_work = exact_work; }\n        let read = queue.read_bits";
    assert_eq!(original.matches(old).count(), 1, "unique mutation anchor");
    fs::write(&path, original.replacen(old, new, 1)).unwrap();
    let result = check_brotli_input_function(&verus, &temporary, function);
    let log = transcript(&result);
    fs::create_dir_all(project.join("evidence")).unwrap();
    fs::write(
        project.join("evidence/canary-brotli-b3c-symbol-work-undercharge.log"),
        &log,
    )
    .unwrap();
    assert!(
        !result.status.success(),
        "prover accepted symbol-work undercharge"
    );
    assert!(
        log.contains("invariant not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("postcondition not satisfied")
            || log.contains("assertion failed"),
        "expected a proof rejection, not a tooling error: {log}",
    );
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_b3c_serialized_symbol_write_undercharge() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-symbol-write-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    let function = "completed_body_symbol_work";
    let positive = check_brotli_input_function(&verus, &temporary, function);
    assert!(
        positive.status.success(),
        "unmodified selected root failed: {}",
        transcript(&positive),
    );

    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    let old = "    const SERIALIZED_WRITE_WORK: u64 = 10 + 5;";
    let new = "    const SERIALIZED_WRITE_WORK: u64 = 10 + 4;";
    assert_eq!(original.matches(old).count(), 1, "unique mutation anchor");
    fs::write(&path, original.replacen(old, new, 1)).unwrap();
    let result = check_brotli_input_function(&verus, &temporary, function);
    let log = transcript(&result);
    fs::create_dir_all(project.join("evidence")).unwrap();
    fs::write(
        project.join("evidence/canary-brotli-b3c-symbol-write-undercharge.log"),
        &log,
    )
    .unwrap();
    assert!(
        !result.status.success(),
        "prover accepted serialized symbol-write undercharge",
    );
    assert!(
        log.contains("postcondition not satisfied") || log.contains("assertion failed"),
        "expected a proof rejection, not a tooling error: {log}",
    );
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_five_b3c_block_count_metering_undercharges() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-block-count-metering-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }

    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-b3c-block-count-planning-bit-undercharge",
            "plan_bit_read",
            "    let work = consumed as u64 + if complete { width as u64 } else { 0 };",
            "    let work = consumed as u64;",
        ),
        (
            "brotli-b3c-block-count-base-write-undercharge",
            "block_count_base_execution_work",
            "{\n    read_work + 10 + 2 + 1\n}",
            "{\n    read_work + 10 + 2\n}",
        ),
        (
            "brotli-b3c-block-count-terminal-write-undercharge",
            "block_count_truncated_execution_work",
            "{\n    block_count_base_execution_work(read_work) + 4 + 1\n}",
            "{\n    block_count_base_execution_work(read_work) + 4\n}",
        ),
        (
            "brotli-b3c-block-count-single-value-undercharge",
            "block_count_value_execution_work",
            "    if raw == 0 {\n        base + 7 + 1",
            "    if raw == 0 {\n        base + 7",
        ),
        (
            "brotli-b3c-block-count-tree-start-undercharge",
            "block_count_value_execution_work",
            "        base + 2 + 77 + 1 + 1",
            "        base + 2 + 75 + 1 + 1",
        ),
    ] {
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::create_dir_all(project.join("evidence")).unwrap();
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied") || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}",
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_three_b3c_distance_metering_undercharges() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-distance-metering-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }

    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-b3c-distance-queue-write-undercharge",
            "distance_base_execution_work",
            "{\n    read_work + 10 + 1\n}",
            "{\n    read_work + 9 + 1\n}",
        ),
        (
            "brotli-b3c-distance-terminal-undercharge",
            "distance_truncated_execution_work",
            "{\n    distance_base_execution_work(read_work) + 4 + 1\n}",
            "{\n    distance_base_execution_work(read_work) + 4\n}",
        ),
        (
            "brotli-b3c-distance-value-undercharge",
            "distance_value_execution_work",
            "{\n    distance_base_execution_work(read_work) + 1 + 2 + 2 + 1 + 1\n}",
            "{\n    distance_base_execution_work(read_work) + 1 + 2 + 2 + 1\n}",
        ),
    ] {
        let start = original
            .find(&format!("fn {function}("))
            .expect("selected mutation function exists");
        let end = start
            + original[start..]
                .find("\n}\n")
                .expect("selected mutation function ends")
            + 3;
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..],
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::create_dir_all(project.join("evidence")).unwrap();
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied") || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}",
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_four_b3c_context_mode_metering_undercharges() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-context-mode-metering-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }

    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-b3c-context-mode-complete-undercharge",
            "context_mode_complete_execution_work",
            "{\n    serialized_map_start_work() + 1 + 1\n}",
            "{\n    13 + 1 + 2\n}",
        ),
        (
            "brotli-b3c-context-mode-queue-undercharge",
            "context_mode_base_execution_work",
            "fn context_mode_base_execution_work(read_work: u64) -> (r: u64)\n    requires read_work <= 63,\n    ensures r == read_work + 10 + 1,\n{\n    read_work + 10 + 1\n}",
            "fn context_mode_base_execution_work(read_work: u64) -> (r: u64)\n    requires read_work <= 63,\n    ensures r == read_work + 10 + 1,\n{\n    read_work + 9 + 1\n}",
        ),
        (
            "brotli-b3c-context-mode-terminal-undercharge",
            "context_mode_truncated_execution_work",
            "{\n    context_mode_base_execution_work(read_work) + 4 + 1\n}",
            "{\n    context_mode_base_execution_work(read_work) + 4\n}",
        ),
        (
            "brotli-b3c-context-mode-value-undercharge",
            "context_mode_value_execution_work",
            "{\n    context_mode_base_execution_work(read_work) + 1 + 2 + 1\n}",
            "{\n    context_mode_base_execution_work(read_work) + 1 + 2\n}",
        ),
    ] {
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::create_dir_all(project.join("evidence")).unwrap();
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied") || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}",
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_four_b3c_initial_suffix_metering_undercharges() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-initial-suffix-metering-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }

    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-b3c-initial-suffix-planning-undercharge",
            "initial_suffix_planning_total",
            "{\n    read_work + 1\n}",
            "{\n    read_work\n}",
        ),
        (
            "brotli-b3c-initial-suffix-queue-undercharge",
            "initial_suffix_base_execution_work",
            "{\n    read_work + 1 + 10 + 1\n}",
            "{\n    read_work + 1 + 9 + 1\n}",
        ),
        (
            "brotli-b3c-initial-suffix-terminal-undercharge",
            "initial_suffix_truncated_execution_work",
            "{\n    initial_suffix_base_execution_work(read_work) + 4 + 1\n}",
            "{\n    initial_suffix_base_execution_work(read_work) + 4\n}",
        ),
        (
            "brotli-b3c-initial-suffix-value-undercharge",
            "initial_suffix_value_execution_work",
            "{\n    initial_suffix_base_execution_work(read_work) + 2 + 4 + 1 + 1 + 1\n}",
            "{\n    initial_suffix_base_execution_work(read_work) + 4 + 1 + 1\n}",
        ),
    ] {
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::create_dir_all(project.join("evidence")).unwrap();
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied") || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}",
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_five_b3c_tree_formula_undercharges() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-tree-metering-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.path().extension().is_some_and(|ext| ext == "rs") {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    // These controls bind the arithmetic contracts only. Full planner/action
    // refinement and source-action coverage remain separate M1 obligations.
    for (name, function, old, new) in [
        (
            "brotli-b3c-simple-install-formula-undercharge",
            "simple_tree_install_work",
            "    if selector == 0 { 5 } else { 3 * alphabet as u64 + 5 }",
            "    if selector == 0 { 4 } else { 3 * alphabet as u64 + 5 }",
        ),
        (
            "brotli-b3c-canonical-install-formula-undercharge",
            "canonical_tree_install_work",
            "    36 * symbols as u64 + 6 * nonzero as u64 + nonzero_index_sum + 1_564 + 4 + 1",
            "    36 * symbols as u64 + 6 * nonzero as u64 + nonzero_index_sum + 1_563 + 4 + 1",
        ),
        (
            "brotli-b3c-repeat-serialization-formula-undercharge",
            "code_description_payload_writes",
            "        CodeDescriptionPhase::ComplexRepeat { .. } => 35,",
            "        CodeDescriptionPhase::ComplexRepeat { .. } => 34,",
        ),
        (
            "brotli-b3c-initial-symbol-formula-undercharge",
            "initial_symbol_execution_work",
            "    let base = checked_planned_work_add(planning_work, 10 + 5 + 1)?;",
            "    let base = checked_planned_work_add(planning_work, 10 + 4 + 1)?;",
        ),
        (
            "brotli-b3c-serialization-base-formula-undercharge",
            "code_description_store_writes",
            "    4 + code_description_payload_writes(phase)",
            "    3 + code_description_payload_writes(phase)",
        ),
    ] {
        assert_eq!(
            original.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(&path, original.replacen(old, new, 1)).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied") || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}",
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_thirteen_b3c_context_tree_count_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-context-count-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.path().extension().is_some_and(|ext| ext == "rs") {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-b3c-context-count-queue-write-undercharge","context_tree_count_execution_work","    let base = read_work + 10 + 2 + 1;","    let base = read_work + 9 + 2 + 1;"),
        ("brotli-b3c-context-count-var-write-undercharge","context_tree_count_execution_work","    let base = read_work + 10 + 2 + 1;","    let base = read_work + 10 + 1 + 1;"),
        ("brotli-b3c-context-count-map-cell-undercharge","context_tree_count_execution_work","            active_len as u64 + 4 + 1 + 1","            active_len as u64 / 2 + 4 + 1 + 1"),
        ("brotli-b3c-context-count-map-progress-undercharge","context_tree_count_execution_work","            active_len as u64 + 4 + 1 + 1","            active_len as u64 + 3 + 1 + 1"),
        ("brotli-b3c-context-count-tree-count-undercharge","context_tree_count_execution_work","        VarUint8Status::Value(raw) => base + 2 + if raw == 0 {","        VarUint8Status::Value(raw) => base + 1 + if raw == 0 {"),
        ("brotli-b3c-context-count-phase-transition-undercharge","context_tree_count_execution_work","            1 + 1\n        },","            1\n        },"),
        ("brotli-b3c-context-count-terminal-undercharge","context_tree_count_execution_work","        VarUint8Status::Truncated => base + 4 + 1,","        VarUint8Status::Truncated => base + 4,"),
        ("brotli-b3c-context-count-planning-debit-omitted","plan_context_tree_count_action","    if !budget.charge_work(read.work) {","    if !budget.charge_work(0) {"),
        ("brotli-b3c-context-count-execution-debit-undercharge","execute_planned_context_tree_count","    if !budget.charge_work(plan.execution_work) {","    if !budget.charge_work(plan.execution_work - 1) {"),
        ("brotli-b3c-context-count-execution-reserved-after-writes","execute_planned_context_tree_count","    if !budget.charge_work(plan.execution_work) {\n        return Err(CompressedStep {\n            consumed: 0, status: CompressedStatus::Failed(CoreFailure::ResourceLimit),\n        });\n    }\n",""),
        ("brotli-b3c-context-count-wrong-decoded-count","advance_context_tree_count_phase","                        let num_trees = raw + 1;","                        let num_trees = raw + 2;"),
        ("brotli-b3c-context-count-wrong-zero-map-value","advance_context_tree_count_phase","                                    kind,\n                                    active_len,\n                                    initialized,\n                                    0,\n                                    1,","                                    kind,\n                                    active_len,\n                                    initialized,\n                                    1,\n                                    1,"),
        ("brotli-b3c-context-count-progress-writes-map-size","store_context_map_progress","    match put_state_u16(workspace, window_bytes, B3B_MAP_INDEX, progress) {","    match put_state_u16(workspace, window_bytes, B3B_MAP_SIZE, progress) {"),
    ] {
        let start = original.find(&format!("fn {function}("))
            .expect("selected function exists");
        let end = start + original[start..].find("\n}\n")
            .expect("selected function ends") + 3;
        let selected = &original[start..end];
        assert_eq!(selected.matches(old).count(), 1, "unique mutation anchor for {name}");
        let mut changed = selected.replacen(old, new, 1);
        if name == "brotli-b3c-context-count-execution-reserved-after-writes" {
            let call = "    let (used, status) = advance_context_tree_count_phase(\n        workspace, window_bytes, kind_tag, kind, active_len, input, end_of_input,\n    );";
            assert_eq!(changed.matches(call).count(), 1, "unique execution site");
            changed = changed.replacen(call, &format!("{call}\n{old}"), 1);
        }
        let mutated = format!("{}{}{}", &original[..start], changed, &original[end..]);
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_seventeen_b3c_context_bits_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-context-bits-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.path().extension().is_some_and(|ext| ext == "rs") {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-b3c-context-bits-queue-undercharge", "context_bits_execution_work", "    let base = read_work + 10 + 1;", "    let base = read_work + 9 + 1;"),
        ("brotli-b3c-context-bits-start-undercharge", "context_bits_execution_work", "{ 76 + 1 + 1 + 1 + 1 }", "{ 75 + 1 + 1 + 1 + 1 }"),
        ("brotli-b3c-context-bits-prefix-undercharge", "context_bits_execution_work", "{ 76 + 1 + 1 + 1 + 1 }", "{ 76 + 1 + 0 + 1 + 1 }"),
        ("brotli-b3c-context-bits-map-undercharge", "context_bits_execution_work", "repeat as u64 + 4 + 1 + 1 + 1", "repeat as u64 / 2 + 4 + 1 + 1 + 1"),
        ("brotli-b3c-context-bits-progress-undercharge", "context_bits_execution_work", "repeat as u64 + 4 + 1 + 1 + 1", "repeat as u64 + 3 + 1 + 1 + 1"),
        ("brotli-b3c-context-bits-reset-undercharge", "context_bits_execution_work", "repeat as u64 + 4 + 1 + 1 + 1", "repeat as u64 + 4 + 0 + 1 + 1"),
        ("brotli-b3c-context-bits-phase-undercharge", "context_bits_execution_work", "} else { 1 + 1 }", "} else { 1 }"),
        ("brotli-b3c-context-bits-terminal-undercharge", "context_bits_execution_work", "BitReadStatus::Truncated => 4 + 1,", "BitReadStatus::Truncated => 4,"),
        ("brotli-b3c-context-bits-planning-debit-omitted", "plan_context_bits_action", "if !budget.charge_work(read.work)", "if !budget.charge_work(0)"),
        ("brotli-b3c-context-bits-execution-debit-undercharge", "execute_planned_context_bits", "if !budget.charge_work(plan.execution_work)", "if !budget.charge_work(plan.execution_work - 1)"),
        ("brotli-b3c-context-bits-execution-reserved-after-writes", "execute_planned_context_bits", "    if !budget.charge_work(plan.execution_work) {\n        return Err(CompressedStep { consumed: 0, status: CompressedStatus::Failed(CoreFailure::ResourceLimit) });\n    }\n", ""),
        ("brotli-b3c-context-bits-wrong-prefix", "advance_context_bits_phase", "let max_run = value as u8 + 1;", "let max_run = value as u8 + 2;"),
        ("brotli-b3c-context-bits-wrong-zero", "advance_context_bits_phase", "initialized, 0, num_trees);", "initialized, 1, num_trees);"),
        ("brotli-b3c-context-bits-start-writes-unrelated-byte", "initialize_code_description_state", "B3B_PENDING_SPAN_LENGTH, 0)", "B3B_GROUP_KIND, 0)"),
        ("brotli-b3c-context-bits-overshoot-terminal-undercharge", "context_bits_execution_work", "if repeat > remaining as u32 { 4 + 1 }", "if repeat > remaining as u32 { 4 }"),
        ("brotli-b3c-context-bits-skips-overshoot-check", "advance_context_bits_phase", "if index as u32 + repeat > active_len as u32 {", "if false {"),
        ("brotli-b3c-context-bits-reads-wrong-width", "advance_context_bits_phase", "let read = queue.read_bits(width, remaining, end_of_input);", "let read = queue.read_bits(width - 1, remaining, end_of_input);"),
    ] {
        let start = original.find(&format!("fn {function}("))
            .expect("selected function exists");
        let end = start + original[start..].find("\n}\n")
            .expect("selected function ends") + 3;
        let selected = &original[start..end];
        assert_eq!(selected.matches(old).count(), 1, "unique mutation anchor for {name}");
        let mut changed = selected.replacen(old, new, 1);
        if name == "brotli-b3c-context-bits-execution-reserved-after-writes" {
            let call = "    let (used, status) = advance_context_bits_phase(workspace, window_bytes, plan.phase,\n        kind_tag, kind, active_len, input, end_of_input);";
            assert_eq!(changed.matches(call).count(), 1, "unique execution site");
            changed = changed.replacen(call, &format!("{call}\n{old}"), 1);
        }
        if name == "brotli-b3c-context-bits-skips-overshoot-check" {
            // Restate the existing post-guard loop/write bound explicitly.
            // Check the hint with the original guard first; neither run changes
            // the function's admitted inputs or requires/ensures contracts.
            let add_bound = |source: &str, guard: &str| {
                let at = source.find(guard).expect("unique repeat guard");
                let begin = at + source[at..].find('{').unwrap();
                let mut depth = 0usize;
                let mut finish = None;
                for (offset, byte) in source.as_bytes()[begin..].iter().enumerate() {
                    if *byte == b'{' { depth += 1; }
                    else if *byte == b'}' {
                        depth -= 1;
                        if depth == 0 { finish = Some(begin + offset + 1); break; }
                    }
                }
                let finish = finish.expect("balanced repeat guard");
                let bound = "\n                            proof {\n                                assert(index as u32 + repeat <= active_len as u32) by (nonlinear_arith)\n                                    requires index as u32 + repeat <= active_len as u32;\n                            }\n";
                format!("{}{}{}", &source[..finish], bound, &source[finish..])
            };
            let positive = add_bound(selected, old);
            fs::write(&path, format!("{}{}{}", &original[..start], positive, &original[end..])).unwrap();
            let positive = check_brotli_input_function(&verus, &temporary, function);
            let positive_log = transcript(&positive);
            fs::write(project.join("evidence/positive-brotli-b3c-repeat-bound-obligation.log"), &positive_log).unwrap();
            assert!(positive.status.success(), "original guard with explicit existing bound failed: {positive_log}");
            changed = add_bound(&changed, new);
        }
        let mutated = format!("{}{}{}", &original[..start], changed, &original[end..]);
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("requires not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_m1_nested_reset_transition_undercharges() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-nested-reset-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-m1-tree-reset-transition-undercharge",
            "serialized_tree_start_work",
            "{ 76 + 1 }",
            "{ 76 }",
        ),
        (
            "brotli-m1-var-reset-transition-undercharge",
            "serialized_map_start_work",
            "{ 14 + 1 + 1 }",
            "{ 14 + 1 }",
        ),
        (
            "brotli-m1-prefix-reset-transition-undercharge",
            "installed_prefix_reset_work",
            "{ 5 + 1 }",
            "{ 5 }",
        ),
        (
            "brotli-m1-group-tree-transition-undercharge",
            "group_tree_start_work",
            "{ serialized_tree_start_work() + 2 + 1 + 1 }",
            "{ serialized_tree_start_work() + 2 + 1 }",
        ),
        (
            "brotli-m1-group-reset-transition-undercharge",
            "tree_group_start_work",
            "{ 4 + 1 + group_tree_start_work() + 1 + 1 }",
            "{ 4 + group_tree_start_work() + 1 + 1 }",
        ),
        (
            "brotli-m1-ready-reset-transition-undercharge",
            "ready_switch_start_work",
            "{ 28 + 1 }",
            "{ 28 }",
        ),
    ] {
        let start = original
            .find(&format!("fn {function}("))
            .expect("selected function exists");
        let end = start
            + original[start..]
                .find("\n\n")
                .expect("selected function ends");
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied") || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_nine_m1_source_refinement_and_debit_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-source-refinement-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-m1-code-field-wrong-width",
            "CodeDescriptionDecoder::advance_field",
            "self.queue.read_bits(width, input, end_of_input)",
            "self.queue.read_bits(width / 2, input, end_of_input)",
        ),
        (
            "brotli-m1-auxiliary-wrong-symbol",
            "decode_auxiliary_symbol",
            "return Some(i as u8);",
            "return Some(i as u8 + 1);",
        ),
        (
            "brotli-m1-complex-start-wrong-previous-length",
            "start_complex_symbol_progress",
            "prev_code_len: 8,",
            "prev_code_len: 7,",
        ),
        (
            "brotli-m1-var-integer-wrong-value",
            "advance_var_uint8",
            "let value = (1u16 << width) + field as u16;",
            "let value = (1u16 << width) + field as u16 + 1;",
        ),
        (
            "brotli-m1-body-metadata-read-not-charged",
            "advance_planned_body_symbol",
            "budget.charge_work(TREE_METADATA_WORK)",
            "budget.charge_work(0)",
        ),
        (
            "brotli-m1-body-execution-undercharge",
            "advance_planned_body_symbol",
            "budget.charge_work(completed_action_work)",
            "budget.charge_work(completed_action_work - 1)",
        ),
        (
            "brotli-m1-context-direct-wrong-value",
            "store_context_direct_symbol",
            "let value = symbol - max_run as u16;",
            "let value = symbol - max_run as u16 + 1;",
        ),
        (
            "brotli-m1-initial-symbol-execution-undercharge",
            "execute_planned_initial_symbol",
            "budget.charge_work(plan.execution_work)",
            "budget.charge_work(plan.execution_work - 1)",
        ),
        (
            "brotli-m1-context-symbol-execution-undercharge",
            "execute_planned_context_symbol",
            "budget.charge_work(plan.execution_work)",
            "budget.charge_work(plan.execution_work - 1)",
        ),
    ] {
        let scope = if function.starts_with("CodeDescriptionDecoder::") {
            original
                .find("impl CodeDescriptionDecoder {")
                .expect("decoder implementation exists")
        } else {
            0
        };
        let function_name = function.rsplit("::").next().unwrap();
        let start = scope
            + original[scope..]
                .find(&format!("fn {function_name}("))
                .expect("selected function exists");
        let end = start
            + original[start..]
                .find("\n}\n")
                .expect("selected function ends")
            + 3;
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_b3c_wrong_dictionary_source() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-b3c-dictionary-source-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for name in [
        "lib.rs",
        "base64.rs",
        "percent.rs",
        "lz4.rs",
        "brotli_input.rs",
        "brotli_block.rs",
        "brotli_prefix.rs",
        "brotli.rs",
        "brotli_data.rs",
        "brotli_dictionary.rs",
        "composition_demo.rs",
    ] {
        fs::copy(
            project.join("src").join(name),
            temporary.join("src").join(name),
        )
        .unwrap();
    }
    let function = "copy_dictionary_slice";
    let positive = check_brotli_data_function_high(&verus, &temporary, function);
    assert!(
        positive.status.success(),
        "unmodified selected root failed: {}",
        transcript(&positive),
    );

    let path = temporary.join("src/brotli_data.rs");
    let original = fs::read_to_string(&path).unwrap();
    let old = "        output[output_start + i] = crate::brotli_dictionary::dictionary_byte(\n            source + body_start + i,\n        );";
    let new = "        output[output_start + i] = crate::brotli_dictionary::dictionary_byte(\n            source + body_start + i + 1,\n        );";
    assert_eq!(original.matches(old).count(), 1, "unique mutation anchor");
    fs::write(&path, original.replacen(old, new, 1)).unwrap();
    let result = check_brotli_data_function_high(&verus, &temporary, function);
    let log = transcript(&result);
    fs::create_dir_all(project.join("evidence")).unwrap();
    fs::write(
        project.join("evidence/canary-brotli-b3c-wrong-dictionary-source.log"),
        &log,
    )
    .unwrap();
    assert!(
        !result.status.success(),
        "prover accepted wrong dictionary source"
    );
    assert!(
        log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("assertion failed"),
        "expected a proof rejection, not a tooling error: {log}",
    );
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_fifteen_m1_saved_table_and_lookup_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-saved-table-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-m1-aux-count-read-not-charged", "auxiliary_count_metered",
            "budget.charge_work(1)", "budget.charge_work(0)"),
        ("brotli-m1-aux-first-code-skips-last-length", "auxiliary_first_code_metered",
            "auxiliary_count_metered(lengths, width, 18, budget)",
            "auxiliary_count_metered(lengths, width, 17, budget)"),
        ("brotli-m1-aux-canonical-length-read-not-charged", "auxiliary_canonical_code_metered",
            "budget.charge_work(1)", "budget.charge_work(0)"),
        ("brotli-m1-aux-candidate-read-not-charged", "decode_auxiliary_symbol_metered",
            "budget.charge_work(1)", "budget.charge_work(0)"),
        ("brotli-m1-aux-singleton-skips-last-length", "auxiliary_singleton_metered",
            "while i < 18", "while i < 17"),
        ("brotli-m1-simple-pair-second-read-not-charged", "simple_symbol_pair_metered",
            "let a = symbols[left];\n    if !budget.charge_work(1)",
            "let a = symbols[left];\n    if !budget.charge_work(0)"),
        ("brotli-m1-simple-validation-skips-last-pair", "simple_distinct_validation_metered",
            "        let equal = simple_symbol_pair_metered(symbols, 2, 3, budget)?;\n        assert(!equal);",
            ""),
        ("brotli-m1-field-planning-replay-not-charged", "plan_code_description_field",
            "budget.charge_work(replay_work)", "budget.charge_work(0)"),
        ("brotli-m1-saved-aux-load-not-charged", "plan_saved_aux_load",
            "budget.charge_work(1)", "budget.charge_work(0)"),
        ("brotli-m1-saved-aux-wrong-partial-count", "plan_saved_aux_load",
            "return Ok((i as u64 + 1, false));", "return Ok((18, false));"),
        ("brotli-m1-saved-aux-skips-last-copy", "read_aux_lengths",
            "while i < 18", "while i < 17"),
        ("brotli-m1-saved-aux-accepts-invalid-length", "read_aux_lengths",
            "if value > 5 {", "if false {"),
        ("brotli-m1-canonical-validation-read-not-charged", "plan_canonical_tree_install",
            "budget.charge_work(1)", "budget.charge_work(0)"),
        ("brotli-m1-canonical-accepts-invalid-length", "plan_canonical_tree_install",
            "if length > 15 {\n            proof { k1_canonical_classification_agrees(lengths@, symbols as nat, planning_work as nat, false); }\n            return Ok((planning_work, planning_work, false));",
            "if length > 15 {\n            proof { k1_canonical_classification_agrees(lengths@, symbols as nat, planning_work as nat, false); }\n            return Ok((planning_work, planning_work, true));"),
        ("brotli-m1-canonical-accepts-incomplete-space", "plan_canonical_tree_install",
            "if nonzero < 2 || space != 0 {", "if nonzero < 2 {"),
    ] {
        let start = original.find(&format!("fn {function}(")).expect("selected function exists");
        let end = start + original[start..].find("\n}\n").expect("selected function ends") + 3;
        let selected = &original[start..end];
        assert_eq!(selected.matches(old).count(), 1, "unique mutation anchor for {name}");
        let mutated = format!("{}{}{}", &original[..start], selected.replacen(old, new, 1), &original[end..]);
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_four_m1_tree_action_bound_and_drain_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-tree-bound-canary-{}",
        std::process::id()
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-m1-parser-restores-too-small-cap",
            "advance_serialized_tree",
            "while work < 5_696",
            "while work < 2_000",
        ),
        (
            "brotli-m1-planner-restores-too-small-cap",
            "plan_serialized_tree",
            "while iterations < 5_696",
            "while iterations < 2_000",
        ),
        (
            "brotli-m1-parser-skips-pending-span-drain",
            "advance_serialized_tree",
            "if matches!(decoder.phase, CodeDescriptionPhase::ComplexPendingSpan { .. }) {",
            "if false {",
        ),
        (
            "brotli-m1-planner-skips-pending-span-drain",
            "plan_serialized_tree",
            "if matches!(decoder.phase, CodeDescriptionPhase::ComplexPendingSpan { .. }) {",
            "if false {",
        ),
    ] {
        let start = original.find(&format!("fn {function}(")).unwrap();
        let end = start + original[start..].find("\n}\n").unwrap() + 3;
        let mut selected = original[start..end].to_string();
        let (old, new) = if name == "brotli-m1-planner-restores-too-small-cap" {
            // Check the existing rank's adequacy for the executable cap before
            // mutation. This derived assertion is valid on the unmodified
            // function; it avoids an expensive fallthrough counterexample.
            let receipt = "    let action_cap: u16 = 5_696;\n    proof { assert(initial_rank < action_cap as nat); }\n    while iterations < action_cap";
            assert_eq!(selected.matches("    while iterations < 5_696").count(), 1);
            selected = selected.replacen("    while iterations < 5_696", receipt, 1);
            fs::write(
                &path,
                format!("{}{}{}", &original[..start], selected, &original[end..]),
            )
            .unwrap();
            let positive = check_brotli_input_function(&verus, &temporary, function);
            fs::write(
                project.join("evidence/positive-brotli-m1-planner-cap-rank.log"),
                transcript(&positive),
            )
            .unwrap();
            assert!(
                positive.status.success(),
                "unmodified cap/rank obligation failed: {}",
                transcript(&positive)
            );
            (
                "let action_cap: u16 = 5_696;",
                "let action_cap: u16 = 2_000;",
            )
        } else {
            (old, new)
        };
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        fs::write(
            &path,
            format!(
                "{}{}{}",
                &original[..start],
                selected.replacen(old, new, 1),
                &original[end..]
            ),
        )
        .unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("requires not satisfied")
                || log.contains("assertion failed")
                || log.contains("invariant not satisfied"),
            "expected semantic proof rejection: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_m1_tree_plan_debit_and_frame_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-tree-refinement-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-m1-tree-plan-omits-saved-load-planning", "plan_serialized_tree",
            "let mut planning_work = initial_planning_work + copy_len as u64;",
            "let mut planning_work = copy_len as u64;"),
        ("brotli-m1-block-tree-plan-omits-planning-debit", "plan_block_tree_action",
            "planning_work: tree.planning_work,", "planning_work: 0,"),
        ("brotli-m1-group-tree-plan-omits-planning-debit", "plan_tree_group_action",
            "planning_work: tree.planning_work,", "planning_work: 0,"),
        ("brotli-m1-pending-span-writes-wrong-length", "drain_serialized_pending_span",
            "next_initialized,\n            length,\n        )",
            "next_initialized,\n            0,\n        )"),
        ("brotli-m1-descriptor-store-writes-unrelated-byte", "store_code_description_decoder",
            "B3B_PENDING_SPAN_LENGTH, 0)", "B3B_PENDING_SPAN_LENGTH + 1, 0)"),
        ("brotli-m1-inconsistent-span-mutates-decoder", "drain_serialized_pending_span",
            "return Err(CompressedHeaderError::InternalState);\n    }\n    let mut written",
            "decoder.phase = CodeDescriptionPhase::Failed(CodeDescriptionError::InvalidAlphabet);\n        return Err(CompressedHeaderError::InternalState);\n    }\n    let mut written"),
    ] {
        let start = original.find(&format!("fn {function}(")).expect("selected function exists");
        let end = start + original[start..].find("\n}\n").expect("selected function ends") + 3;
        let selected = &original[start..end];
        assert_eq!(selected.matches(old).count(), 1, "unique mutation anchor for {name}");
        let mutated = format!("{}{}{}", &original[..start], selected.replacen(old, new, 1), &original[end..]);
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("requires not satisfied")
            || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_m1_block_count_relation_and_debit_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-block-relation-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-m1-block-count-prepass-omits-read-work", "block_count_planning_work",
            "Ok(read.work)", "Ok(0)"),
        ("brotli-m1-block-count-plan-loses-need-input", "plan_block_count_action",
            "VarUint8Status::NeedInput => Some(CompressedHeaderStatus::NeedInput),",
            "VarUint8Status::NeedInput => None,"),
        ("brotli-m1-block-count-plan-loses-consumption", "plan_block_count_action",
            "consumed: step.consumed,", "consumed: 0,"),
        ("brotli-m1-block-count-executor-omits-input-debit", "execute_fixed_compressed_plan",
            "budget.charge_input(used as u64)", "budget.charge_input(0)"),
        ("brotli-m1-block-count-limited-input-is-retryable", "execute_fixed_compressed_plan",
            "if input_was_limited { CompressedStatus::Failed(CoreFailure::ResourceLimit) }",
            "if input_was_limited && phase != CompressedOuterPhase::BlockCount { CompressedStatus::Failed(CoreFailure::ResourceLimit) }"),
        ("brotli-m1-block-count-value-writes-padding", "apply_block_count_value",
            "let count = raw + 1;",
            "put_state_byte(self.workspace, self.window_bytes, 175, 255)?;\n        let count = raw + 1;"),
    ] {
        let start = original.find(&format!("fn {function}(")).expect("selected function exists");
        let indent = original[..start].rsplit('\n').next().unwrap().len();
        let closing = format!("\n{}}}\n", " ".repeat(indent));
        let end = start + original[start..].find(&closing).expect("selected function ends") + closing.len();
        let selected = &original[start..end];
        assert_eq!(selected.matches(old).count(), 1, "unique mutation anchor for {name}");
        let mutated = format!("{}{}{}", &original[..start], selected.replacen(old, new, 1), &original[end..]);
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("requires not satisfied")
            || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_m1_distance_relation_and_frame_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-distance-relation-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-m1-distance-prepass-omits-read-work",
            "distance_planning_work",
            "Ok(read.work)",
            "Ok(0)",
        ),
        (
            "brotli-m1-distance-plan-loses-need-input",
            "plan_distance_action",
            "Some(CompressedHeaderStatus::NeedInput),",
            "None,",
        ),
        (
            "brotli-m1-distance-plan-loses-consumption",
            "plan_distance_action",
            "consumed: read.consumed,",
            "consumed: 0,",
        ),
        (
            "brotli-m1-distance-plan-omits-value-writes",
            "plan_distance_action",
            "distance_value_execution_work(read_plan.work)",
            "distance_base_execution_work(read_plan.work)",
        ),
        (
            "brotli-m1-distance-action-writes-wrong-direct-field",
            "advance_distance_parameters_phase",
            "B3B_DIRECT_DISTANCE, direct)",
            "B3B_ALPHABET_LIMIT, direct)",
        ),
        (
            "brotli-m1-distance-action-flips-postfix",
            "advance_distance_parameters_phase",
            "B3B_DISTANCE_POSTFIX, postfix)",
            "B3B_DISTANCE_POSTFIX, postfix ^ 1)",
        ),
    ] {
        let start = original
            .find(&format!("fn {function}("))
            .expect("selected function exists");
        let indent = original[..start].rsplit('\n').next().unwrap().len();
        let closing = format!("\n{}}}\n", " ".repeat(indent));
        let end = start
            + original[start..]
                .find(&closing)
                .expect("selected function ends")
            + closing.len();
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("requires not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_m1_bad_context_count_failure_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-context-count-failure-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-m1-context-bad-count-prepass-skips-terminal-plan", "context_mode_planning_work", "if literal_count == 0 || literal_count > 256 || initialized > literal_count {\n        return Ok(0);", "if literal_count == 0 || literal_count > 256 || initialized > literal_count {\n        return Err(CompressedHeaderError::InternalState);"),
        ("brotli-m1-context-bad-count-plan-omits-terminal-work", "plan_context_mode_action", "execution_work: 4 + 1,", "execution_work: 0,"),
        ("brotli-m1-context-bad-count-plan-loses-failure", "plan_context_mode_action", "status: Some(CompressedHeaderStatus::Failed(CompressedHeaderError::InternalState))", "status: None"),
        ("brotli-m1-context-bad-count-plan-consumes-input", "plan_context_mode_action", "consumed: 0, status: Some(CompressedHeaderStatus::Failed(CompressedHeaderError::InternalState))", "consumed: 1, status: Some(CompressedHeaderStatus::Failed(CompressedHeaderError::InternalState))"),
        ("brotli-m1-context-bad-count-executor-wrong-error", "execute_fixed_compressed_plan", "CompressedStatus::Failed(map_compressed_error(error))", "CompressedStatus::Failed(CoreFailure::Truncated)"),
        ("brotli-m1-context-bad-count-owner-skips-action", "advance_planned_compressed_action", "        match execute_fixed_compressed_plan(\n            workspace,\n            window_bytes,\n            budget,\n            CompressedOuterPhase::ContextModes,", "        return Err(CompressedStep { consumed: 0, status: CompressedStatus::Failed(core_state_failure()) });\n        match execute_fixed_compressed_plan(\n            workspace,\n            window_bytes,\n            budget,\n            CompressedOuterPhase::ContextModes,"),
    ] {
        let start = original.find(&format!("fn {function}(")).expect("selected function exists");
        let indent = original[..start].rsplit('\n').next().unwrap().len();
        let closing = format!("\n{}}}\n", " ".repeat(indent));
        let end = start + original[start..].find(&closing).expect("selected function ends") + closing.len();
        let selected = &original[start..end];
        assert_eq!(selected.matches(old).count(), 1, "unique mutation anchor for {name}");
        let mutated = format!("{}{}{}", &original[..start], selected.replacen(old, new, 1), &original[end..]);
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(log.contains("postcondition not satisfied")
            || log.contains("precondition not satisfied")
            || log.contains("invariant not satisfied")
            || log.contains("requires not satisfied")
            || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_eight_m1_context_mode_relation_and_frame_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-context-mode-relation-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-m1-context-mode-prepass-omits-read-work",
            "context_mode_planning_work",
            "Ok(read.work)",
            "Ok(0)",
        ),
        (
            "brotli-m1-context-mode-plan-loses-need-input",
            "plan_context_mode_action",
            "Some(CompressedHeaderStatus::NeedInput),",
            "None,",
        ),
        (
            "brotli-m1-context-mode-plan-loses-consumption",
            "plan_context_mode_action",
            "consumed: read.consumed,",
            "consumed: 0,",
        ),
        (
            "brotli-m1-context-mode-plan-omits-value-writes",
            "plan_context_mode_action",
            "context_mode_value_execution_work(read_plan.work)",
            "context_mode_base_execution_work(read_plan.work)",
        ),
        (
            "brotli-m1-context-mode-action-writes-wrong-value",
            "advance_context_modes_phase",
            "                                    value as u8,
                                )",
            "                                    (value as u8) ^ 1,
                                )",
        ),
        (
            "brotli-m1-context-mode-action-loses-initialized-count",
            "advance_context_modes_phase",
            "B3B_MODES_INITIALIZED, next)",
            "B3B_MODES_INITIALIZED, initialized)",
        ),
        ("brotli-m1-context-mode-executor-omits-input-debit", "execute_fixed_compressed_plan", "budget.charge_input(used as u64)", "budget.charge_input(if phase == CompressedOuterPhase::ContextModes { 0 } else { used as u64 })"),
        ("brotli-m1-context-mode-limited-input-is-retryable", "execute_fixed_compressed_plan", "if input_was_limited { CompressedStatus::Failed(CoreFailure::ResourceLimit) }", "if input_was_limited && phase != CompressedOuterPhase::ContextModes { CompressedStatus::Failed(CoreFailure::ResourceLimit) }"),
    ] {
        let start = original
            .find(&format!("fn {function}("))
            .expect("selected function exists");
        let indent = original[..start].rsplit('\n').next().unwrap().len();
        let closing = format!("\n{}}}\n", " ".repeat(indent));
        let end = start
            + original[start..]
                .find(&closing)
                .expect("selected function ends")
            + closing.len();
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("requires not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_two_k2_context_mode_success_guarantee_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-k2-writer-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_prefix.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-k2-writer-rejects-last-valid-index",
            "write_next_context_mode",
            "initialized >= LITERAL_CONTEXT_MODES_BYTES as u16",
            "initialized >= LITERAL_CONTEXT_MODES_BYTES as u16 - 1",
        ),
        (
            "brotli-k2-writer-rejects-valid-window",
            "write_next_context_mode",
            "if window_bytes > 16_777_216",
            "if window_bytes >= 16_777_216",
        ),
    ] {
        let start = original
            .find(&format!("fn {function}("))
            .expect("selected function exists");
        let indent = original[..start]
            .rsplit('\n')
            .next()
            .unwrap()
            .chars()
            .take_while(|c| c.is_whitespace())
            .count();
        let closing = format!("\n{}}}\n", " ".repeat(indent));
        let end = start
            + original[start..]
                .find(&closing)
                .expect("selected function ends")
            + closing.len();
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_prefix_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("requires not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires an unchanged whole-crate positive and VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_five_k1_k3_success_and_preservation_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-k1-k3-canary-{}", std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_prefix.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-k1-installer-rejects-valid-two-symbol-tree",
            "install_builder_canonical_tree",
            "    let mut symbol: u16 = 0;\n    let mut space: u32 = CODE_SPACE;",
            "    if symbols == 2 { return Err(WorkspaceError::InvalidCodeLength); }\n    let mut symbol: u16 = 0;\n    let mut space: u32 = CODE_SPACE;",
        ),
        (
            "brotli-k1-invalid-length-changes-metadata",
            "install_builder_canonical_tree",
            "            return Err(WorkspaceError::InvalidCodeLength);\n        }\n        if length != 0 {",
            "            meta.symbols = 0;\n            return Err(WorkspaceError::InvalidCodeLength);\n        }\n        if length != 0 {",
        ),
        (
            "brotli-k1-invalid-length-changes-builder",
            "install_builder_canonical_tree",
            "            return Err(WorkspaceError::InvalidCodeLength);\n        }\n        if length != 0 {",
            "            workspace[window_bytes as usize + BUILDER_CODE_LENGTHS_OFFSET as usize] = 0;\n            return Err(WorkspaceError::InvalidCodeLength);\n        }\n        if length != 0 {",
        ),
        (
            "brotli-k3-rejects-valid-symbol-and-suffix",
            "decode_block_length",
            "    match offset.checked_add(suffix) {",
            "    if symbol == 0 && suffix == 0 { return Err(PrefixError::InvalidBlockLengthSuffix); }\n    match offset.checked_add(suffix) {",
        ),
        (
            "brotli-k3-decodes-wrong-block-length",
            "decode_block_length",
            "Some(value) => Ok(value)",
            "Some(value) => Ok(value + 1)",
        ),
    ] {
        let start = original.find(&format!("fn {function}(")).unwrap();
        let end = start + original[start..].find("\n}\n").unwrap() + 3;
        let selected = &original[start..end];
        let body = selected.find("\n{\n").expect("executable body");
        assert_eq!(selected[body..].matches(old).count(), 1, "unique body mutation for {name}");
        let replacement = format!("{}{}", &selected[..body], selected[body..].replacen(old, new, 1));
        assert_eq!(&replacement[..body], &selected[..body], "unchanged root contract");
        fs::write(&path, format!("{}{}{}", &original[..start], replacement, &original[end..])).unwrap();
        let result = check_brotli_prefix_function(&verus, &temporary, function);
        let log = transcript(&result);
        let lower = log.to_ascii_lowercase();
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied") || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied") || log.contains("assertion failed"),
            "expected a semantic proof rejection: {log}"
        );
        assert!(
            !lower.contains("resource limit") && !lower.contains("panicked")
                && !lower.contains("expected rlimit-count"),
            "tool/resource failure is not a semantic rejection: {log}"
        );
        println!("REJECTED {name}: deliberate source defect, unchanged specification");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires an unchanged whole-crate positive and VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_three_k3_suffix_plan_relation_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-k3-suffix-canary-{}", std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    let function = "plan_initial_suffix_action";
    let start = original.find(&format!("fn {function}(")).unwrap();
    let end = start + original[start..].find("\n}\n").unwrap() + 3;
    let selected = &original[start..end];
    let body = selected.find("\n{\n").unwrap();
    for (name, old, new) in [
        (
            "brotli-k3-suffix-plan-loses-consumption",
            "let result = CompressedActionPlan { planning_work, execution_work, consumed: read.consumed, status };",
            "let result = CompressedActionPlan { planning_work, execution_work, consumed: 0, status };",
        ),
        (
            "brotli-k3-suffix-plan-loses-success",
            "Ok(_) => None,",
            "Ok(_) => Some(CompressedHeaderStatus::NeedInput),",
        ),
        (
            "brotli-k3-suffix-plan-undercharges-value-tables",
            "if !budget.charge_work(2)",
            "if !budget.charge_work(1)",
        ),
    ] {
        assert_eq!(selected[body..].matches(old).count(), 1, "unique body mutation for {name}");
        let replacement = format!("{}{}", &selected[..body], selected[body..].replacen(old, new, 1));
        assert_eq!(&replacement[..body], &selected[..body], "unchanged root contract");
        fs::write(&path, format!("{}{}{}", &original[..start], replacement, &original[end..])).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        let lower = log.to_ascii_lowercase();
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(log.contains("postcondition not satisfied") || log.contains("assertion failed"),
            "expected a semantic proof rejection: {log}");
        assert!(!lower.contains("resource limit") && !lower.contains("panicked")
            && !lower.contains("expected rlimit-count"), "tool/resource failure is not a semantic rejection: {log}");
        println!("REJECTED {name}: deliberate source defect, unchanged specification");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_m1_context_mode_handoff_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-context-mode-handoff-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-m1-handoff-reset-writes-wrong-var-phase",
            "start_context_map",
            "store_var_uint8_phase(workspace, window_bytes, VarUint8Phase::First)",
            "store_var_uint8_phase(workspace, window_bytes, VarUint8Phase::Short)",
        ),
        (
            "brotli-m1-handoff-reset-writes-wrong-pending-run",
            "start_context_map",
            "B3B_PENDING_RUN, 255)?;",
            "B3B_PENDING_RUN, 0)?;",
        ),
        (
            "brotli-m1-handoff-plan-undercharges-one",
            "plan_context_mode_action",
            "execution_work: context_mode_complete_execution_work(),",
            "execution_work: context_mode_complete_execution_work() - 1,",
        ),
        (
            "brotli-m1-handoff-plan-consumes-input",
            "plan_context_mode_action",
            "execution_work: context_mode_complete_execution_work(),\n            consumed: 0,",
            "execution_work: context_mode_complete_execution_work(),\n            consumed: 1,",
        ),
        (
            "brotli-m1-handoff-action-skips-literal-map",
            "advance_context_modes_phase",
            "CompressedOuterPhase::LiteralContextMap) {",
            "CompressedOuterPhase::DistanceContextMap) {",
        ),
        (
            "brotli-m1-handoff-reset-writes-padding",
            "start_context_map",
            "let kind_tag = match kind {",
            "put_state_byte(workspace, window_bytes, 175, 255)?;\n    let kind_tag = match kind {",
        ),
    ] {
        let start = original
            .find(&format!("fn {function}("))
            .expect("selected function exists");
        let indent = original[..start].rsplit('\n').next().unwrap().len();
        let closing = format!("\n{}}}\n", " ".repeat(indent));
        let end = start
            + original[start..]
                .find(&closing)
                .expect("selected function ends")
            + closing.len();
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("requires not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_m1_bad_fixed_cursor_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-bad-fixed-cursor-canary-{}",
        std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-m1-cursor-tag-rejects-with-wrong-error", "read_b3b_state_tag", "return Err(crate::brotli_prefix::WorkspaceError::InvalidSymbol);", "return Err(crate::brotli_prefix::WorkspaceError::InvalidTree);"),
        ("brotli-m1-cursor-distance-prepass-forgets-rejection", "distance_planning_work", "let queue = load_b3b_queue(workspace, window_bytes)?;", "let queue = match load_b3b_queue(workspace, window_bytes) { Ok(value) => value, Err(_) => return Ok(0) };"),
        ("brotli-m1-cursor-block-prepass-forgets-var-rejection", "block_count_planning_work", "let phase = load_var_uint8_phase(workspace, window_bytes)?;", "let phase = match load_var_uint8_phase(workspace, window_bytes) { Ok(value) => value, Err(_) => return Ok(0) };"),
        ("brotli-m1-cursor-block-forecast-omits-terminal-work", "advance_planned_compressed_action", "let failure_plan = CompressedActionPlan { planning_work: 0, execution_work: 4 + 1,\n                    consumed: 0, status: Some(CompressedHeaderStatus::Failed(CompressedHeaderError::InternalState)) };\n                return execute_fixed_compressed_plan(workspace, window_bytes, budget,\n                    CompressedOuterPhase::BlockCount,", "let failure_plan = CompressedActionPlan { planning_work: 0, execution_work: 0,\n                    consumed: 0, status: Some(CompressedHeaderStatus::Failed(CompressedHeaderError::InternalState)) };\n                return execute_fixed_compressed_plan(workspace, window_bytes, budget,\n                    CompressedOuterPhase::BlockCount,"),
        ("brotli-m1-cursor-context-owner-skips-terminal-action", "advance_planned_compressed_action", "return execute_fixed_compressed_plan(workspace, window_bytes, budget,\n                    CompressedOuterPhase::ContextModes,", "return Err(CompressedStep { consumed: 0, status: CompressedStatus::Failed(core_state_failure()) });\n                return execute_fixed_compressed_plan(workspace, window_bytes, budget,\n                    CompressedOuterPhase::ContextModes,"),
        ("brotli-m1-cursor-executor-forgets-terminal-work-debit", "execute_fixed_compressed_plan", "if !budget.charge_work(plan.execution_work) {", "if !budget.charge_work(if plan.execution_work == 5 { 0 } else { plan.execution_work }) {"),
    ] {
        let start = original
            .find(&format!("fn {function}("))
            .expect("selected function exists");
        let indent = original[..start].rsplit('\n').next().unwrap().len();
        let closing = format!("\n{}}}\n", " ".repeat(indent));
        let end = start
            + original[start..]
                .find(&closing)
                .expect("selected function ends")
            + closing.len();
        let selected = &original[start..end];
        assert_eq!(
            selected.matches(old).count(),
            1,
            "unique mutation anchor for {name}"
        );
        let mutated = format!(
            "{}{}{}",
            &original[..start],
            selected.replacen(old, new, 1),
            &original[end..]
        );
        fs::write(&path, mutated).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        fs::write(
            project.join("evidence").join(format!("canary-{name}.log")),
            &log,
        )
        .unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(
            log.contains("postcondition not satisfied")
                || log.contains("precondition not satisfied")
                || log.contains("invariant not satisfied")
                || log.contains("requires not satisfied")
                || log.contains("assertion failed"),
            "expected a proof rejection, not a tooling error: {log}"
        );
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires an unchanged whole-crate positive and VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_six_k4_repeat_codec_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-k4-repeat-canary-{}", std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-k4-repeat-store-overwrites-history",
            "store_complex_code_description_payload",
            "CodeDescriptionPhase::ComplexRepeat { progress, length, .. } => {\n            store_complex_progress(workspace, window_bytes, progress)?;\n            proof { source_writes = source_writes + 34; }\n            put_state_byte(workspace, window_bytes, B3B_PENDING_SPAN_LENGTH, length)?;",
            "CodeDescriptionPhase::ComplexRepeat { progress, length, .. } => {\n            store_complex_progress(workspace, window_bytes, progress)?;\n            proof { source_writes = source_writes + 34; }\n            put_state_byte(workspace, window_bytes, B3B_REPEATED_LENGTH, length)?;",
        ),
        (
            "brotli-k4-repeat-load-current-from-history",
            "load_code_description_decoder",
            "let repeat_length = match state_byte(\n                        workspace, window_bytes, B3B_PENDING_SPAN_LENGTH) {",
            "let repeat_length = match state_byte(\n                        workspace, window_bytes, B3B_REPEATED_LENGTH) {",
        ),
        (
            "brotli-k4-progress-stores-previous-code-in-history",
            "store_complex_progress",
            "(B3B_REPEATED_LENGTH, progress.repeat_code_len)",
            "(B3B_REPEATED_LENGTH, progress.prev_code_len)",
        ),
        (
            "brotli-k4-repeat-load-history-from-current",
            "load_code_description_decoder",
            "let repeated = match state_byte(workspace, window_bytes, B3B_REPEATED_LENGTH) {",
            "let repeated = match state_byte(workspace, window_bytes, if tag == 6 { B3B_PENDING_SPAN_LENGTH } else { B3B_REPEATED_LENGTH }) {",
        ),
        (
            "brotli-k4-repeat-width-uses-old-class",
            "load_code_description_decoder",
            "let extra_bits = if repeat_length == 0 { 3 } else { 2 };",
            "let extra_bits = if repeated == 0 { 3 } else { 2 };",
        ),
        (
            "brotli-k4-repeat-rejects-valid-length-fifteen",
            "load_code_description_decoder",
            "if repeat_length > 15 {",
            "if repeat_length >= 15 {",
        ),
    ] {
        let start = original.find(&format!("fn {function}(")).unwrap();
        let end = start + original[start..].find("\n}\n").unwrap() + 3;
        let selected = &original[start..end];
        let body = selected.find("\n{\n").unwrap();
        assert_eq!(selected[body..].matches(old).count(), 1, "unique body mutation for {name}");
        let replacement = format!("{}{}", &selected[..body], selected[body..].replacen(old, new, 1));
        assert_eq!(&replacement[..body], &selected[..body], "unchanged root contract");
        fs::write(&path, format!("{}{}{}", &original[..start], replacement, &original[end..])).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        let lower = log.to_ascii_lowercase();
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(lower.contains("postcondition not satisfied") || lower.contains("precondition not satisfied")
            || lower.contains("invariant not satisfied") || lower.contains("assertion failed"),
            "expected a semantic proof rejection: {log}");
        assert!(!lower.contains("resource limit") && !lower.contains("panicked")
            && !lower.contains("expected rlimit-count"), "tool/resource failure is not a semantic rejection: {log}");
        println!("REJECTED {name}: deliberate source defect, unchanged specification");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires an unchanged whole-crate positive and VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_fourteen_k5_loader_accounting_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-k5-loader-canary-{}", std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        ("brotli-k5-loader-omits-four-simple-copies", "plan_saved_loader_read_units", "let base = 4 + aux_reads;", "let base = aux_reads;"),
        ("brotli-k5-prefix-validation-scan-undercharge", "plan_saved_loader_read_units", "return Ok(base + if 1 <= auxiliary_phase && auxiliary_phase <= 3 { 18u64 } else { 0u64 });", "return Ok(base + if 1 <= auxiliary_phase && auxiliary_phase <= 3 { 17u64 } else { 0u64 });"),
        ("brotli-k5-singleton-guard-reordered-before-scan", "plan_saved_loader_read_units", "|| prefix_bits >= (1u8 << prefix_width) || singleton >= 18 {", "|| prefix_bits >= (1u8 << prefix_width) || prefix_width != 0 || singleton >= 18 {"),
        ("brotli-k5-selected-singleton-read-unpaid", "plan_saved_singleton_validation_reads", "if !budget.charge_work(1) { return Err(CoreFailure::ResourceLimit); }\n    let selected", "if !budget.charge_work(0) { return Err(CoreFailure::ResourceLimit); }\n    let selected"),
        ("brotli-k5-singleton-skips-last-validation-cell", "plan_saved_singleton_validation_reads", "while i < 18", "while i < 17"),
        ("brotli-k5-simple-right-comparison-operand-unpaid", "plan_saved_simple_validation_reads", "if !budget.charge_work(1) { return Err(CoreFailure::ResourceLimit); }\n            let right", "if !budget.charge_work(0) { return Err(CoreFailure::ResourceLimit); }\n            let right"),
        ("brotli-k5-simple-omits-right-operand-receipt", "plan_saved_simple_validation_reads", "let right = state_u16(workspace, window_bytes, B3B_SIMPLE_SYMBOLS + 2 * j as u16)\n                .map_err(map_compressed_error)?;\n            inspected += 1;", "let right = state_u16(workspace, window_bytes, B3B_SIMPLE_SYMBOLS + 2 * j as u16)\n                .map_err(map_compressed_error)?;\n            inspected += 0;"),
        ("brotli-k5-selector-reload-keeps-old-eighteen", "valid_code_loader_read_units", "_ => 22,", "_ => 18,"),
        ("brotli-k5-prefix-reload-omits-validation-cell", "valid_code_loader_read_units", "valid_complex_code_scan_is_18(ComplexCodeLengthAlphabet { skip: progress.skip, lengths: progress.lengths }); }\n            40", "valid_complex_code_scan_is_18(ComplexCodeLengthAlphabet { skip: progress.skip, lengths: progress.lengths }); }\n            39"),
        ("brotli-k5-singleton-reload-omits-selected-cell", "valid_code_loader_read_units", "CodeDescriptionPhase::ComplexSymbol(progress)\n        | CodeDescriptionPhase::ComplexRepeat { progress, .. } => {\n            proof { valid_complex_symbol_validation_count(progress, decoder.alphabet_limit); }\n            40 + if progress.singleton < 18 { 18u64 } else { 0u64 }", "CodeDescriptionPhase::ComplexSymbol(progress)\n        | CodeDescriptionPhase::ComplexRepeat { progress, .. } => {\n            proof { valid_complex_symbol_validation_count(progress, decoder.alphabet_limit); }\n            40 + if progress.singleton < 18 { 17u64 } else { 0u64 }"),
        ("brotli-k5-initial-loader-replay-unpaid", "plan_serialized_tree", "budget.charge_work(loader_reads)", "budget.charge_work(0)"),
        ("brotli-k5-each-reload-restores-old-eighteen", "plan_serialized_tree", "checked_planned_work_add(execution_work, reload_reads)", "checked_planned_work_add(execution_work, 18)"),
        ("brotli-k5-invalid-last-auxiliary-misclassified-valid", "plan_saved_aux_load", "return Ok((i as u64 + 1, false));", "return Ok((i as u64 + 1, true));"),
        ("brotli-k5-invalid-alphabet-misclassified-valid", "plan_saved_aux_load", "return Ok((0, false));", "return Ok((0, true));"),
    ] {
        let start = original.find(&format!("fn {function}(")).unwrap();
        let end = start + original[start..].find("\n}\n").unwrap() + 3;
        let selected = &original[start..end];
        let body = selected.find("\n{\n").unwrap();
        assert_eq!(selected[body..].matches(old).count(), 1, "unique body mutation for {name}");
        let replacement = format!("{}{}", &selected[..body], selected[body..].replacen(old, new, 1));
        assert_eq!(&replacement[..body], &selected[..body], "unchanged root contract");
        fs::write(&path, format!("{}{}{}", &original[..start], replacement, &original[end..])).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        let lower = log.to_ascii_lowercase();
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(lower.contains("postcondition not satisfied") || lower.contains("precondition not satisfied")
            || lower.contains("invariant not satisfied") || lower.contains("assertion failed"),
            "expected a semantic proof rejection: {log}");
        assert!(!lower.contains("resource limit") && !lower.contains("panicked")
            && !lower.contains("expected rlimit-count"), "tool/resource failure is not a semantic rejection: {log}");
        println!("REJECTED {name}: deliberate source defect, unchanged specification");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}

#[test]
#[ignore = "requires an unchanged whole-crate positive and VERUS_ROOT pointing at the pinned Verus distribution"]
fn the_prover_rejects_twelve_m1_general_codec_defects() {
    let verus_root = PathBuf::from(std::env::var_os("VERUS_ROOT").expect("set VERUS_ROOT"));
    let verus = verus_root.join(if cfg!(windows) { "verus.exe" } else { "verus" });
    let project = Path::new(env!("CARGO_MANIFEST_DIR"));
    let temporary = std::env::temp_dir().join(format!(
        "proven-primitives-m1-general-codec-canary-{}", std::process::id(),
    ));
    fs::create_dir(&temporary).expect("fresh private temporary directory");
    fs::create_dir(temporary.join("src")).unwrap();
    for entry in fs::read_dir(project.join("src")).unwrap() {
        let entry = entry.unwrap();
        if entry.file_type().unwrap().is_file() {
            fs::copy(entry.path(), temporary.join("src").join(entry.file_name())).unwrap();
        }
    }
    let path = temporary.join("src/brotli_input.rs");
    let original = fs::read_to_string(&path).unwrap();
    for (name, function, old, new) in [
        (
            "brotli-m1-codec-simple-index-erased",
            "store_simple_code_description_payload",
            "put_state_byte(workspace, window_bytes, B3B_CODE_INDEX, index)?;",
            "put_state_byte(workspace, window_bytes, B3B_CODE_INDEX, 0)?;",
        ),
        (
            "brotli-m1-codec-shape-selector-lost",
            "store_simple_code_description_payload",
            "put_state_byte(workspace, window_bytes, B3B_SIMPLE_SELECTOR, 3)?;",
            "put_state_byte(workspace, window_bytes, B3B_SIMPLE_SELECTOR, 2)?;",
        ),
        (
            "brotli-m1-codec-symbol-array-alias",
            "write_simple_symbols",
            "            symbols[i],",
            "            symbols[0],",
        ),
        (
            "brotli-m1-codec-aux-array-erased",
            "write_aux_lengths",
            "            lengths[i],",
            "            0,",
        ),
        (
            "brotli-m1-codec-prefix-phase-alias",
            "store_complex_code_description_payload",
            "CodeDescriptionPhase::ComplexPrefix3(_) => 2,",
            "CodeDescriptionPhase::ComplexPrefix3(_) => 3,",
        ),
        (
            "brotli-m1-codec-prefix-nonzero-erased",
            "store_complex_code_description_payload",
            "put_state_byte(workspace, window_bytes, B3B_AUX_NONZERO, progress.nonzero)?;",
            "put_state_byte(workspace, window_bytes, B3B_AUX_NONZERO, 0)?;",
        ),
        (
            "brotli-m1-codec-aux-skip-erased",
            "store_complex_code",
            "put_state_byte(workspace, window_bytes, B3B_AUX_SKIP, code.skip)",
            "put_state_byte(workspace, window_bytes, B3B_AUX_SKIP, 0)",
        ),
        (
            "brotli-m1-codec-chained-history-erased",
            "store_complex_progress",
            "put_state_u32(workspace, window_bytes, B3B_CHAINED_REPEAT, progress.repeat)",
            "put_state_u32(workspace, window_bytes, B3B_CHAINED_REPEAT, 0)",
        ),
        (
            "brotli-m1-codec-parent-tag-erased",
            "store_code_description_decoder",
            "put_state_byte(workspace, window_bytes, B3B_CODE_PHASE, tag)",
            "put_state_byte(workspace, window_bytes, B3B_CODE_PHASE, 0)",
        ),
        (
            "brotli-m1-codec-failed-error-tag-alias",
            "code_description_error_tag",
            "CodeDescriptionError::InvalidAlphabet => 2,",
            "CodeDescriptionError::InvalidAlphabet => 3,",
        ),
        (
            "brotli-m1-codec-simple-write-undercharge",
            "store_simple_code_description_payload",
            "put_state_byte(workspace, window_bytes, B3B_CODE_INDEX, index)?;\n            proof { source_writes = source_writes + 1; }",
            "put_state_byte(workspace, window_bytes, B3B_CODE_INDEX, index)?;\n            proof { source_writes = source_writes + 0; }",
        ),
        (
            "brotli-m1-codec-complex-write-undercharge",
            "store_complex_code_description_payload",
            "CodeDescriptionPhase::ComplexSymbol(progress) => {\n            store_complex_progress(workspace, window_bytes, progress)?;\n            proof { source_writes = source_writes + 34; }",
            "CodeDescriptionPhase::ComplexSymbol(progress) => {\n            store_complex_progress(workspace, window_bytes, progress)?;\n            proof { source_writes = source_writes + 33; }",
        ),
    ] {
        let start = original.find(&format!("fn {function}(")).unwrap();
        let end = start + original[start..].find("\n}\n").unwrap() + 3;
        let selected = &original[start..end];
        let body = selected.find("\n{\n").unwrap();
        assert_eq!(selected[body..].matches(old).count(), 1, "unique body mutation for {name}");
        let replacement = format!("{}{}", &selected[..body], selected[body..].replacen(old, new, 1));
        assert_eq!(&replacement[..body], &selected[..body], "unchanged root contract");
        fs::write(&path, format!("{}{}{}", &original[..start], replacement, &original[end..])).unwrap();
        let result = check_brotli_input_function(&verus, &temporary, function);
        let log = transcript(&result);
        let lower = log.to_ascii_lowercase();
        fs::write(project.join("evidence").join(format!("canary-{name}.log")), &log).unwrap();
        assert!(!result.status.success(), "prover accepted {name}");
        assert!(lower.contains("postcondition not satisfied") || lower.contains("precondition not satisfied")
            || lower.contains("invariant not satisfied") || lower.contains("assertion failed"),
            "expected a semantic proof rejection: {log}");
        assert!(!lower.contains("resource limit") && !lower.contains("panicked")
            && !lower.contains("expected rlimit-count"), "tool/resource failure is not a semantic rejection: {log}");
        println!("REJECTED {name}: deliberate source defect, unchanged specification");
        fs::write(&path, &original).unwrap();
    }
    fs::remove_dir_all(temporary).unwrap();
}
