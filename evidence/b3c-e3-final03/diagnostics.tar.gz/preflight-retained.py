from pathlib import Path
import re,json,shutil,subprocess,concurrent.futures,importlib.util
R=Path.cwd();O=R/'target/b3c-e3/preflight-retained01';O.mkdir(exist_ok=False);s=(R/'tests/proof_rejection.rs').read_text();a=s.index('fn the_prover_rejects_ten_b3c_atomic_emission_defects()');a=s.index('    for (name, function, old, new) in [',a);b=s.index('    ] {',a);q=r'("(?:[^"\\]|\\.)*")';pat=r'\(\s*'+r'\s*,\s*'.join([q]*4)+r'\s*,?\s*\)';cases=[tuple(json.loads(v) for v in row) for row in re.findall(pat,s[a:b])];assert len(cases)==10
spec=importlib.util.spec_from_file_location('h',R/'target/m1-r-final-gate/driver.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
original=(R/'src/brotli.rs').read_text()
for name,fn,old,new in cases:
 folder=O/name;shutil.copytree(R/'src',folder/'src');begin='    fn emit_byte(' if fn.endswith('::emit_byte') else '    fn emit_uncompressed_byte(';following='    fn emit_uncompressed_byte(' if fn.endswith('::emit_byte') else '    fn fail_transition(';a=original.index(begin);b=original.index(following,a);part=original[a:b];body=part.index('\n    {\n');assert part[body:].count(old)==1;changed=part[:body]+part[body:].replace(old,new,1);assert changed[:body]==part[:body];(folder/'src/brotli.rs').write_text(original[:a]+changed+original[b:])
def check(case):
 name,fn,old,new=case;folder=O/name;cmd=[str(g.TOOL/'verus'),str(folder/'src/lib.rs'),'--crate-type','lib','--verify-only-module','brotli','--verify-function',fn,'--no-cheating','--num-threads','1','--triggers-mode','silent','--rlimit','300']
 with (folder/'negative.log').open('w') as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 d={'name':name,'function':fn,'command':cmd,'exit_code':p.returncode,'log_sha256':g.file_hash(folder/'negative.log'),**g.semantic_rejection((folder/'negative.log').read_text()),'counts_as_final_gate':False};(folder/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);return d
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(check,cases))
(O/'results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(x['semantic_rejection'] and not x['tool_or_resource_failure'] and not x['syntax_or_type_failure'] for x in results)
