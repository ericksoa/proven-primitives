from pathlib import Path
import re,json,shutil,hashlib,subprocess,concurrent.futures,importlib.util
R=Path.cwd();O=R/'target/b3c-emission/preflight-controls01';O.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('helpers',R/'target/m1-r-final-gate/driver.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
test=(R/'tests/proof_rejection.rs').read_text();a=test.index('fn the_prover_rejects_ten_b3c_atomic_emission_defects()');a=test.index('    for (name, function, old, new) in [',a);b=test.index('    ] {',a);block=test[a:b]
string=r'("(?:[^"\\]|\\.)*")';pattern=r'\(\s*'+r'\s*,\s*'.join([string]*4)+r'\s*,\s*\)'
cases=[tuple(json.loads(v) for v in values) for values in re.findall(pattern,block)]
assert len(cases)==10
original=(R/'src/brotli.rs').read_text();(O/'original-brotli.rs').write_text(original)
selected=cases[3:]
for name,function,old,new in selected:
 folder=O/name;shutil.copytree(R/'src',folder/'src')
 begin,following=('    fn emit_byte(','    fn emit_uncompressed_byte(') if function.endswith('::emit_byte') else ('    fn emit_uncompressed_byte(','    fn fail_transition(')
 start=original.index(begin);end=original.index(following,start);part=original[start:end];body=part.index('\n    {\n')
 assert part[body:].count(old)==1,name
 changed=part[:body]+part[body:].replace(old,new,1);assert changed[:body]==part[:body]
 (folder/'src/brotli.rs').write_text(original[:start]+changed+original[end:])
def check(row):
 name,function,old,new=row;folder=O/name;cmd=[str(g.TOOL/'verus'),str(folder/'src/lib.rs'),'--crate-type','lib','--verify-only-module','brotli','--verify-function',function,'--no-cheating','--num-threads','1','--triggers-mode','silent','--rlimit','60']
 with (folder/'negative.log').open('w') as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 text=(folder/'negative.log').read_text();classification=g.semantic_rejection(text)
 result={'name':name,'function':function,'command':cmd,'exit_code':p.returncode,'source_sha256':g.file_hash(folder/'src/brotli.rs'),'log_sha256':g.file_hash(folder/'negative.log'),**classification,'counts_as_final_gate_case':False}
 (folder/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'case':name,'exit_code':p.returncode,**classification}),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(check,selected))
(O/'results.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
assert all(x['exit_code']!=0 and x['semantic_rejection'] and not x['tool_or_resource_failure'] and not x['syntax_or_type_failure'] for x in results)
