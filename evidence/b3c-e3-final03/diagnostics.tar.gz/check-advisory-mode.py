from pathlib import Path
import subprocess,json,hashlib,importlib.util
R=Path.cwd();O=R/'target/b3c-e3/advisory-mode-pair01';O.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('h',R/'target/m1-r-final-gate/driver.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
negative=Path('/var/folders/w3/n8mr0lln07n_mc7k11fjqn800000gp/T/proven-primitives-b3c-emission-canaries-43675/src/lib.rs')
s=(R/'src/brotli.rs').read_text();bad=(negative.parent/'brotli.rs').read_text();a=s.index('    fn emit_byte(');b=s.index('    fn emit_uncompressed_byte(',a);part=s[a:b];old='crate::brotli_input::B3C_SECOND_PREVIOUS_BYTE,\n                previous,';new=old.replace('previous,','byte,');assert part.count(old)==1 and bad==s[:a]+part.replace(old,new,1)+s[b:]
helpout=subprocess.check_output([str(g.TOOL/'verus'),'--help'],text=True);(O/'verifier-help.txt').write_text(helpout);assert 'Do not automatically check recommends after' in helpout
rows=[]
for name,source in [('positive',R/'src/lib.rs'),('negative',negative)]:
 cmd=[str(g.TOOL/'verus'),str(source),'--crate-type','lib','--verify-only-module','brotli','--verify-function','BrotliDecoder::emit_byte','--no-cheating','--num-threads','1','--triggers-mode','silent','--rlimit','300','--no-auto-recommends-check']
 with (O/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 text=(O/(name+'.log')).read_text();row={'name':name,'command':cmd,'exit_code':p.returncode,'log_sha256':g.file_hash(O/(name+'.log')),**g.semantic_rejection(text)};rows.append(row);(O/'steps.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if name=='positive':assert p.returncode==0,text
 else:assert p.returncode!=0 and row['semantic_rejection'] and not row['tool_or_resource_failure'] and not row['syntax_or_type_failure'],text
